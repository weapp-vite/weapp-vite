//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/platform/globals.mjs
function e$26() {
	return typeof globalThis > `u` ? void 0 : globalThis;
}
function t$23() {
	return e$26()?.wx ?? (typeof wx > `u` ? void 0 : wx);
}
var DEFAULT_RUNTIME_CAPABILITIES = Object.freeze({
	globalPageStack: true,
	globalCreateSelectorQuery: true,
	selectorQueryScopeByIn: true,
	globalCreateIntersectionObserver: true,
	intersectionObserverScopeByParameter: true,
	pageShareMenu: true,
	shareTimelineRequiresShareAppMessage: true,
	pageScrollApi: true,
	pullDownRefreshApi: true,
	globalRouterApi: true,
	appErrorListener: true,
	appPageNotFoundListener: true,
	appUnhandledRejectionListener: true,
	appThemeChangeListener: true,
	appMemoryWarningListener: true
});
({ ...DEFAULT_RUNTIME_CAPABILITIES });
({ ...DEFAULT_RUNTIME_CAPABILITIES });
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/platform/current.mjs
var f$12 = t$23;
var m$12 = () => DEFAULT_RUNTIME_CAPABILITIES;
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/platform.mjs
function o$26(e) {
	return m$12()[e] === !0;
}
function s$21() {
	if (!o$26(`globalPageStack`)) return [];
	let n = e$26(), r = f$12(), i = r?.getCurrentPages ?? n?.getCurrentPages ?? (typeof getCurrentPages < `u` ? getCurrentPages : void 0);
	if (typeof i != `function`) return [];
	try {
		let e = i.call(r);
		return Array.isArray(e) ? e : [];
	} catch {
		return [];
	}
}
function l$19() {
	return f$12() ?? e$26();
}
function u$19() {
	return l$19()?.console?.warn;
}
//#endregion
//#region ../../node_modules/.pnpm/@weapp-core+constants@0.3.0/node_modules/@weapp-core/constants/dist/index.js
var WEAPP_VITE_RUNTIME_VIRTUAL_ID = "virtual:weapp-vite/runtime";
`${WEAPP_VITE_RUNTIME_VIRTUAL_ID}`;
`${WEAPP_VITE_RUNTIME_VIRTUAL_ID}`;
var WEAPP_I18N_DIRECTORY = "i18n";
`${WEAPP_I18N_DIRECTORY}`;
`${WEAPP_I18N_DIRECTORY}`;
var WEAPP_VITE_STATEFUL_HMR_DIRECTORY = "__weapp_vite_hmr";
`${WEAPP_VITE_STATEFUL_HMR_DIRECTORY}`;
`${WEAPP_VITE_STATEFUL_HMR_DIRECTORY}`;
`${WEAPP_VITE_STATEFUL_HMR_DIRECTORY}`;
var WEAPP_VITE_STATEFUL_HMR_BRIDGE_KEY = "__WEAPP_VITE_STATEFUL_HMR_BRIDGE__";
var WEVU_BINDING_MANIFEST_KEY = "__wevuBindingManifest";
var WEVU_INLINE_MAP_KEY = "__weapp_vite_inline_map";
var WEVU_SLOT_OWNER_ID_KEY = "__wvOwnerId";
var WEVU_SLOT_OWNER_ID_PROP = "__wvSlotOwnerId";
var WEVU_SLOT_SCOPE_KEY = "__wvSlotScope";
var WEVU_SLOT_NAMES_PROP = "vueSlots";
var WEVU_SCOPED_SLOT_OWNER_REQUIRED_KEY = "__wevuScopedSlotOwnerRequired";
var WEVU_PROPS_KEY = "__wevuProps";
var WEVU_SETUP_STATE_KEY = "__wevuSetupState";
var WEVU_CSS_MODULES_KEY = "__wevuCssModules";
var WEVU_PROPS_ALIASES_KEY = "__wevuPropsAliases";
var WEVU_PROPS_DERIVED_KEYS_KEY = "__wevuPropsDerivedKeys";
var WEVU_ATTRS_KEY = "__wevuAttrs";
var WEVU_NATIVE_INSTANCE_KEY = "__wevuNativeInstance";
var WEVU_RUNTIME_KEY = "__wevuRuntime";
var WEVU_RESOLVE_PUBLIC_INSTANCE_METHOD = "__weapp_vite_resolvePublicInstance";
var WEVU_HOST_COMMIT_PROMISE_KEY = "__wevuHostCommitPromise";
var WEVU_FUNCTION_PROP_PATHS_KEY = "__wevuFunctionPropPaths";
var WEVU_SETUP_CONTEXT_INSTANCE_KEY = "__wevuSetupContextInstance";
var WEVU_PROP_KEYS_KEY = "__wevuPropKeys";
var WEVU_READY_CALLED_KEY = "__wevuReadyCalled";
var WEVU_PENDING_PROP_VALUES_KEY = "__wevuPendingPropValues";
var WEVU_ON_LOAD_CALLED_KEY = "__wevuOnLoadCalled";
var WEVU_PAGE_SCROLL_HOOK_DEPTH_KEY = "__wevuPageScrollHookDepth";
var WEVU_ON_BEFORE_UNMOUNT_HOOK = "__wevuOnBeforeUnmount";
var WEVU_HOOKS_KEY = "__wevuHooks";
var WEVU_EXPOSED_KEY = "__wevuExposed";
var WEVU_PUBLIC_RUNTIME_KEY = "$wevu";
var WEVU_RUNTIME_APP_KEY = "__wevuRuntimeApp";
var WEVU_IS_APP_INSTANCE_KEY = "__wevuIsAppInstance";
var WEVU_APP_PROVIDES_KEY = "__wevuAppProvides";
var WEVU_PROVIDES_KEY = "__wevuProvides";
var WEVU_PARENT_INSTANCE_KEY = "__wevuParentInstance";
var WEVU_WATCH_STOPS_KEY = "__wevuWatchStops";
var WEVU_EFFECT_SCOPE_KEY = "__wevuEffectScope";
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/hooks/base.mjs
var o$25 = (() => {
	let e = typeof globalThis < `u` ? globalThis : l$19();
	return e ? e["__wevuCurrentSetupState__"] ?? (e["__wevuCurrentSetupState__"] = {}) : {};
})();
function s$20() {
	return o$25.instance;
}
function c$21(e) {
	o$25.instance = e;
}
function l$18() {
	return o$25.context;
}
function u$18(e) {
	o$25.context = e;
}
function d$16(e) {
	if (!o$25.instance) throw Error(`${e}() 必须在 setup() 的同步阶段调用`);
	return o$25.instance;
}
function f$11(e) {
	return e["__wevuHooks"] || (e["__wevuHooks"] = Object.create(null)), e[WEVU_HOOKS_KEY];
}
function h$7(e, t, n, { single: r = !1 } = {}) {
	let i = f$11(e);
	r ? i[t] = n : (i[t] ?? (i[t] = [])).push(n);
}
function v$4(e, t, n = []) {
	let r = e[WEVU_HOOKS_KEY];
	if (!r) return;
	let i = r[t];
	if (!i) return;
	let o = e.__wevu?.proxy ?? e;
	if (Array.isArray(i)) for (let e of i) try {
		e.apply(o, n);
	} catch {}
	else if (typeof i == `function`) try {
		i.apply(o, n);
	} catch {}
}
function y$4(e, t, n = []) {
	let r = e[WEVU_HOOKS_KEY];
	if (!r) return;
	let i = r[t];
	if (!i) return;
	let o = e.__wevu?.proxy ?? e;
	if (typeof i == `function`) try {
		return i.apply(o, n);
	} catch {
		return;
	}
	if (Array.isArray(i)) {
		let e;
		for (let t of i) try {
			e = t.apply(o, n);
		} catch {}
		return e;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/hooks/pageScroll.mjs
function i$23(e, t) {
	let r = e, i = Number(r["__wevuPageScrollHookDepth"] ?? 0);
	r[WEVU_PAGE_SCROLL_HOOK_DEPTH_KEY] = i + 1;
	try {
		return t();
	} finally {
		i === 0 ? delete r[WEVU_PAGE_SCROLL_HOOK_DEPTH_KEY] : r[WEVU_PAGE_SCROLL_HOOK_DEPTH_KEY] = i;
	}
}
function a$23(t, a, o) {
	let s = Number(t["__wevuPageScrollHookDepth"] ?? 0) > 0;
	return i$23(t, () => (s || (v$4(t, "__wevuPageScrollObservers", a), v$4(t, `onPageScroll`, a)), o?.apply(t, a)));
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/hooks/vue.mjs
function o$24(t) {
	h$7(d$16(`onMounted`), `onReady`, t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/_virtual/_@oxc-project_runtime@0.151.0/helpers/esm/typeof.mjs
function e$25(t) {
	"@babel/helpers - typeof";
	return e$25 = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == `function` && e.constructor === Symbol && e !== Symbol.prototype ? `symbol` : typeof e;
	}, e$25(t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/_virtual/_@oxc-project_runtime@0.151.0/helpers/esm/toPrimitive.mjs
function t$22(t, n) {
	if (e$25(t) != `object` || !t) return t;
	var r = t[Symbol.toPrimitive];
	if (r !== void 0) {
		var i = r.call(t, n || `default`);
		if (e$25(i) != `object`) return i;
		throw TypeError(`@@toPrimitive must return a primitive value.`);
	}
	return (n === `string` ? String : Number)(t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/_virtual/_@oxc-project_runtime@0.151.0/helpers/esm/toPropertyKey.mjs
function n$22(n) {
	var r = t$22(n, `string`);
	return e$25(r) == `symbol` ? r : r + ``;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/_virtual/_@oxc-project_runtime@0.151.0/helpers/esm/defineProperty.mjs
function t$21(t, n, r) {
	return (n = n$22(n)) in t ? Object.defineProperty(t, n, {
		value: r,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : t[n] = r, t;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/scheduler.mjs
var e$24 = Promise.resolve();
var t$20 = /* @__PURE__ */ new Set();
var n$21 = /* @__PURE__ */ new Set();
var r$15 = !1;
var i$22 = !1;
var a$22;
var o$23;
function s$19() {
	i$22 = !1, r$15 = !0, a$22 = /* @__PURE__ */ new Set();
	let e = !1, o = !1, c, l = [];
	try {
		t$20.forEach((e) => {
			a$22?.add(e);
			try {
				let t = e();
				t && typeof t.then == `function` && l.push(t);
			} catch (e) {
				o || (o = !0, c = e);
			}
		});
	} finally {
		t$20.clear(), a$22 = void 0, r$15 = !1, n$21.size && (n$21.forEach((e) => t$20.add(e)), n$21.clear(), i$22 = !0, e = !0);
	}
	if (l.length || e) return Promise.all(l).then(() => e ? s$19() : void 0).then(() => {
		if (o) throw c;
	}, (e) => {
		throw o ? c : e;
	});
	if (o) throw c;
}
function c$20() {
	let t = e$24.then(s$19);
	o$23 = t;
	let n = () => {
		o$23 === t && (o$23 = void 0);
	};
	t.then(n, n);
}
function l$17(e) {
	if (r$15 && a$22?.has(e)) {
		n$21.add(e);
		return;
	}
	t$20.add(e), !r$15 && !i$22 && (i$22 = !0, c$20());
}
function u$17(t) {
	let n = o$23 ?? e$24;
	return t ? n.then(t) : n;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/core.mjs
var n$20 = /* @__PURE__ */ new WeakMap();
var r$14 = null;
var i$21 = [];
var a$21 = !0;
var o$22;
var s$18 = 0;
var c$19 = !1;
var l$16 = /* @__PURE__ */ new Set();
var u$16 = /* @__PURE__ */ new Set();
function d$15(e) {
	if (e.active) {
		if (e.scheduler) {
			let t = o$22;
			o$22 = e._scope;
			try {
				e.scheduler();
			} finally {
				o$22 = t;
			}
			return;
		}
		e();
	}
}
function p$11() {
	s$18++;
}
function m$11(e) {
	let t = e.values().next();
	if (!t.done) return e.delete(t.value), t.value;
}
function h$6() {
	let e, t = !1;
	c$19 = !0;
	try {
		for (; l$16.size;) {
			let n = m$11(l$16);
			if (n) try {
				d$15(n);
			} catch (n) {
				t || (e = n, t = !0);
			}
		}
	} finally {
		c$19 = !1;
	}
	for (; u$16.size;) {
		let n = u$16.values().next().value;
		u$16.delete(n);
		try {
			n();
		} catch (n) {
			t || (e = n, t = !0);
		}
	}
	if (t) throw e;
}
function g$6() {
	s$18 !== 0 && (s$18--, s$18 === 0 && !c$19 && h$6());
}
function _$6(e) {
	p$11();
	try {
		return e();
	} finally {
		g$6();
	}
}
function v$3(e) {
	let { deps: t } = e;
	for (let n = 0; n < t.length; n++) t[n].delete(e);
	t.length = 0;
}
function y$3(e) {
	e.active && (e.active = !1, v$3(e), e.onStop?.());
}
var b$2 = class {
	constructor(e = !1) {
		if (this.detached = e, t$21(this, `active`, !0), t$21(this, `effects`, []), t$21(this, `cleanups`, []), t$21(this, `parent`, void 0), t$21(this, `scopes`, void 0), !e && o$22) {
			var n;
			if (!o$22.active) {
				this.active = !1;
				return;
			}
			this.parent = o$22, ((n = o$22).scopes || (n.scopes = [])).push(this);
		}
	}
	run(e) {
		if (!this.active) return;
		let t = o$22;
		o$22 = this;
		try {
			return e();
		} finally {
			o$22 = t;
		}
	}
	stop() {
		if (!this.active) return;
		this.active = !1;
		let e = o$22;
		o$22 = this;
		let t, n = !1, r = (e) => {
			n || (t = e, n = !0);
		};
		try {
			let e = this.effects.splice(0);
			for (let t of e) try {
				y$3(t);
			} catch (e) {
				r(e);
			}
			let t = this.cleanups.splice(0);
			for (let e of t) try {
				e();
			} catch (e) {
				r(e);
			}
			let n = this.scopes;
			if (this.scopes = void 0, n) {
				for (let e of n) try {
					e.stop();
				} catch (e) {
					r(e);
				}
				n.length = 0;
			}
		} finally {
			if (this.parent?.scopes) {
				let e = this.parent.scopes.indexOf(this);
				e >= 0 && this.parent.scopes.splice(e, 1);
			}
			this.parent = void 0, o$22 = e;
		}
		if (n) throw t;
	}
};
function x$3(e = !1) {
	return new b$2(e);
}
function C$4(e) {
	o$22?.active && o$22.cleanups.push(e);
}
function T$3(e) {
	if (o$22) {
		if (o$22.active) {
			o$22.effects.push(e);
			return;
		}
		y$3(e);
	}
}
function E$3(e, t = {}) {
	let n = function() {
		if (!n.active || n._running) return e();
		v$3(n);
		let t = o$22;
		o$22 = n._scope;
		let s = a$21;
		try {
			return a$21 = !0, n._running = !0, i$21.push(n), r$14 = n, e();
		} finally {
			i$21.pop(), r$14 = i$21[i$21.length - 1] ?? null, n._running = !1, o$22 = t, a$21 = s;
		}
	};
	return n.deps = [], n.scheduler = t.scheduler, n.onStop = t.onStop, n.active = !0, n._running = !1, n._fn = e, n._scope = o$22, n;
}
function D$2(e, t, n) {
	let r = E$3(e, t);
	return r._computed = n, T$3(r), t.lazy || r(), r;
}
function O$2(e, t = {}) {
	return D$2(e, t, !1);
}
function k$2(e, t = {}) {
	return D$2(e, t, !0);
}
function A$1(e, t) {
	if (!a$21 || !r$14) return;
	let i = n$20.get(e);
	i || (i = /* @__PURE__ */ new Map(), n$20.set(e, i));
	let o = i.get(t);
	o || (o = /* @__PURE__ */ new Set(), i.set(t, o)), o.has(r$14) || (o.add(r$14), r$14.deps.push(o));
}
function j$1(e) {
	if (!e._running) {
		if (e._computed) {
			d$15(e);
			return;
		}
		if (s$18 > 0 || c$19) {
			l$16.add(e);
			return;
		}
		d$15(e);
	}
}
function M$1(e, t) {
	let i = n$20.get(e);
	if (!i) return;
	let a = i.get(t);
	if (!a) return;
	let o = /* @__PURE__ */ new Set();
	a.forEach((e) => {
		e !== r$14 && o.add(e);
	}), o.forEach(j$1);
}
function N$2(e) {
	a$21 && r$14 && (e.has(r$14) || (e.add(r$14), r$14.deps.push(e)));
}
function P$1(e) {
	new Set(e).forEach(j$1);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/mutation.mjs
var e$23 = /* @__PURE__ */ new Set();
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/patchState.mjs
var t$19 = /* @__PURE__ */ new WeakMap();
var n$19 = /* @__PURE__ */ new WeakMap();
var r$13 = /* @__PURE__ */ new WeakMap();
var i$20 = /* @__PURE__ */ new WeakMap();
var a$20 = /* @__PURE__ */ new WeakSet();
var o$21 = /* @__PURE__ */ new WeakMap();
var s$17 = /* @__PURE__ */ new WeakMap();
function c$18(e) {
	let t = s$17.get(e);
	return t || (t = /* @__PURE__ */ new Set(), s$17.set(e, t)), t;
}
function l$15(e, t) {
	c$18(e).add(t);
}
function u$15(e) {
	n$19.set(e, (n$19.get(e) ?? 0) + 1);
}
function d$14(e) {
	return n$19.get(e) ?? 0;
}
function f$10(e, n) {
	let r = t$19.get(n) ?? n, i = t$19.get(e);
	(!i || i === e || i === n) && t$19.set(e, r);
}
function p$10(e) {
	let t = /* @__PURE__ */ new Set(), n = [e];
	for (let e = 0; e < 2e3 && n.length; e++) {
		let e = n.pop(), r = i$20.get(e);
		if (r) for (let e of r.keys()) t.has(e) || (t.add(e), u$15(e), n.push(e));
	}
}
function m$10(e) {
	let t = i$20.get(e);
	if (!t) {
		a$20.delete(e), r$13.delete(e);
		return;
	}
	let n, o, s = 0;
	for (let [e, r] of t) {
		for (let t of r) {
			if (s += 1, s > 1) break;
			n = e, o = t;
		}
		if (s > 1) break;
	}
	if (s === 1 && n && o) {
		a$20.delete(e), r$13.set(e, {
			parent: n,
			key: o
		});
		return;
	}
	a$20.add(e), r$13.delete(e);
}
function h$5(n, o, s) {
	if (typeof s != `string`) {
		a$20.add(n), r$13.delete(n);
		return;
	}
	if (e$23.size) {
		let e = t$19.get(o) ?? o;
		l$15(e, o), l$15(e, n);
	}
	let c = i$20.get(n);
	c || (c = /* @__PURE__ */ new Map(), i$20.set(n, c));
	let u = c.get(o);
	u || (u = /* @__PURE__ */ new Set(), c.set(o, u)), u.add(s), m$10(n);
}
function g$5(e, t, n) {
	let r = i$20.get(e);
	if (!r) return;
	let a = r.get(t);
	a && (a.delete(n), a.size || r.delete(t), r.size || i$20.delete(e), m$10(e));
}
function _$5(e, t) {
	if (t === e) return [];
	if (a$20.has(t)) return;
	let n = [], i = t;
	for (let t = 0; t < 2e3; t++) {
		if (i === e) return n.reverse();
		if (a$20.has(i)) return;
		let t = r$13.get(i);
		if (!t || typeof t.key != `string`) return;
		n.push(t.key), i = t.parent;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/shared.mjs
function e$22(e) {
	return typeof e == `object` && !!e;
}
function t$18(e, t) {
	return Object.prototype.hasOwnProperty.call(e, t);
}
function n$18(e) {
	return Object.prototype.toString.call(e).slice(8, -1);
}
function r$12(e) {
	switch (e) {
		case `Object`:
		case `Array`: return 1;
		case `Map`:
		case `Set`:
		case `WeakMap`:
		case `WeakSet`: return 0;
		default: return 0;
	}
}
function i$19(e) {
	return e.__r_skip ? 0 : r$12(n$18(e));
}
var a$19 = Symbol(`wevu.version`);
function o$20(e) {
	if (!e) return !1;
	let t = e.charCodeAt(0);
	if (t < 48 || t > 57) return !1;
	let n = Number(e);
	return Number.isInteger(n) && n >= 0 && String(n) === e;
}
function s$16(e) {
	return e?.__r_raw ?? e;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/state.mjs
var e$21 = /* @__PURE__ */ new WeakMap();
var t$17 = /* @__PURE__ */ new WeakMap();
var n$17 = /* @__PURE__ */ new WeakMap();
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/patch.mjs
function g$4(t) {
	A$1(s$16(t), a$19);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive/shallow.mjs
var d$13 = {
	get(t, n, r) {
		if (n === `__r_isReactive`) return !0;
		if (n === `__r_raw`) return t;
		let i = Reflect.get(t, n, r);
		return A$1(t, n), i;
	},
	set(e, r, a, o) {
		let s = Reflect.get(e, r, o), c = Reflect.set(e, r, a, o);
		return Object.is(s, a) || (M$1(e, r), M$1(e, a$19), u$15(e)), c;
	},
	deleteProperty(e, r) {
		let a = t$18(e, r), s = Reflect.deleteProperty(e, r);
		return a && s && (M$1(e, r), M$1(e, a$19), u$15(e)), s;
	},
	ownKeys(t) {
		return A$1(t, Symbol.iterator), A$1(t, a$19), Reflect.ownKeys(t);
	}
};
function f$9(e) {
	if (!e$22(e) || e.__r_isReactive) return e;
	let t = n$17.get(e);
	if (t) return t;
	if (i$19(e) === 0) return e;
	let n = new Proxy(e, d$13);
	return n$17.set(e, n), t$17.set(n, e), n$19.has(e) || n$19.set(e, 0), n;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/reactive.mjs
function j(e) {
	return d$14(s$16(e));
}
function M(e, t, n) {
	if (!e$23.size || typeof t != `string` || t.startsWith(`__r_`)) return;
	let r = t$19.get(e) ?? e, a = Array.isArray(e) && (t === `length` || o$20(t)) ? `array` : `property`, o = _$5(r, e);
	if (!o) {
		let o = /* @__PURE__ */ new Set(), s = i$20.get(e);
		if (s) for (let [e, t] of s) {
			let n = o$21.get(e), i = n ? n.split(`.`, 1)[0] : void 0, a = i ? void 0 : _$5(r, e)?.[0];
			for (let e of t) typeof e == `string` && o.add(i ?? a ?? e);
		}
		else o.add(t);
		for (let e of e$23) e({
			root: r,
			kind: a,
			op: n,
			path: void 0,
			fallbackTopKeys: o.size ? [...o] : void 0
		});
		return;
	}
	let s = o.findIndex((e) => o$20(e));
	if (s !== -1) {
		let e = o.slice(0, s).join(`.`) || void 0;
		for (let t of e$23) t({
			root: r,
			kind: `array`,
			op: n,
			path: e
		});
		return;
	}
	let c = o.length ? o.join(`.`) : ``, l = a === `array` ? c || void 0 : c ? `${c}.${t}` : t;
	for (let e of e$23) e({
		root: r,
		kind: a,
		op: n,
		path: l
	});
}
var N$1 = {
	get(e, n, r) {
		if (n === `__r_isReactive`) return !0;
		if (n === `__r_raw`) return e;
		let a = Reflect.get(e, n, r);
		if (A$1(e, n), e$22(a)) {
			if (a.__r_skip) return a;
			let t = a?.__r_raw ?? a;
			f$10(t, e), h$5(t, e, n);
			let r = o$21.get(e);
			if (e$23.size && typeof n == `string` && r != null && !a$20.has(t)) {
				let e = r ? `${r}.${n}` : n;
				o$21.set(t, e);
			}
			return P(a);
		}
		return a;
	},
	set(t, r, a, l) {
		let d = t$18(t, r), m = Array.isArray(t), _ = m ? t.length : 0, y = Reflect.get(t, r, l), w = e$22(y) ? s$16(y) : y, T = e$22(a) ? s$16(a) : a;
		if (Object.is(w, T)) return !0;
		let E = Reflect.set(t, r, a, l);
		if (E) {
			let a = e$22(w) ? w : void 0;
			if (a && g$5(a, t, r), e$22(T) && !T.__r_skip) {
				let e = T;
				f$10(e, t), h$5(e, t, r);
				let n = o$21.get(t);
				if (e$23.size && typeof r == `string` && n != null && !a$20.has(e)) {
					let t = n ? `${n}.${r}` : r;
					o$21.set(e, t);
				}
			}
			_$6(() => {
				M$1(t, r), m && typeof r == `string` && o$20(r) && Number(r) >= _ && M$1(t, `length`), M$1(t, a$19), u$15(t), p$10(t);
				let e = t$19.get(t);
				e && e !== t && (M$1(e, a$19), u$15(e)), d || M$1(t, Symbol.iterator);
			}), M(t, r, `set`);
		}
		return E;
	},
	deleteProperty(t, r) {
		let i = t$18(t, r), a = i ? t[r] : void 0, o = Reflect.deleteProperty(t, r);
		if (i && o) {
			let i = e$22(a) ? a?.__r_raw ?? a : void 0;
			i && g$5(i, t, r), _$6(() => {
				M$1(t, r), M$1(t, a$19), u$15(t), p$10(t);
				let e = t$19.get(t);
				e && e !== t && (M$1(e, a$19), u$15(e)), M$1(t, Symbol.iterator);
			}), M(t, r, `delete`);
		}
		return o;
	},
	ownKeys(e) {
		return A$1(e, Symbol.iterator), A$1(e, a$19), Reflect.ownKeys(e);
	}
};
function P(e) {
	if (!e$22(e) || e.__r_isReactive) return e;
	let t = e$21.get(e);
	if (t) return t;
	if (i$19(e) === 0) return e;
	let n = new Proxy(e, N$1);
	return e$21.set(e, n), t$17.set(n, e), n$19.has(e) || n$19.set(e, 0), t$19.has(e) || t$19.set(e, e), n;
}
function F(e) {
	return !!(e && e.__r_isReactive);
}
function I(e) {
	return e$22(e) ? P(e) : e;
}
function L(e) {
	return e$22(e) && Object.defineProperty(e, "__r_skip", {
		value: !0,
		configurable: !0,
		enumerable: !1,
		writable: !0
	}), e;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/ref.mjs
var a$18 = `__v_isRef`;
function o$19(e) {
	try {
		Object.defineProperty(e, a$18, {
			value: !0,
			configurable: !0
		});
	} catch {
		e[a$18] = !0;
	}
	return e;
}
function s$15(e) {
	return !!(e && typeof e == `object` && e.__v_isRef === !0);
}
var c$17 = class {
	constructor(t) {
		t$21(this, `_value`, void 0), t$21(this, `_rawValue`, void 0), t$21(this, `dep`, void 0), o$19(this), this._rawValue = t, this._value = I(t);
	}
	get value() {
		return this.dep || (this.dep = /* @__PURE__ */ new Set()), N$2(this.dep), this._value;
	}
	set value(e) {
		Object.is(e, this._rawValue) || (this._rawValue = e, this._value = I(e), this.dep && P$1(this.dep));
	}
};
function l$14(e) {
	return s$15(e) ? e : L(new c$17(e));
}
function u$14(e) {
	return s$15(e) ? e.value : e;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/computed.mjs
var a$17 = /* @__PURE__ */ new WeakSet();
function s$14(o) {
	let s, c, l = typeof o == `function`;
	l ? (s = o, c = () => {
		throw Error(`计算属性是只读的`);
	}) : (s = o.get, c = o.set);
	let u, d = !0, f, p = {
		get value() {
			return d && (u = f(), d = !1), A$1(p, `value`), u;
		},
		set value(e) {
			c(e);
		}
	};
	return o$19(p), L(p), a$17.add(p), Object.defineProperty(p, "__r_isReadonly", { value: l }), f = k$2(s, {
		lazy: !0,
		scheduler: () => {
			d || (d = !0, M$1(p, `value`));
		}
	}), p;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/defaults.mjs
var e$20 = `__wevuDefaultsScope`;
var t$16 = {};
function n$16(e) {
	if (e && typeof e == `object` && !Array.isArray(e)) return e;
}
function r$11(e, t) {
	if (!e) return t;
	if (!t) return e;
	let r = {
		...e,
		...t
	}, i = n$16(e.setData), a = n$16(t.setData);
	(i || a) && (r.setData = {
		...i ?? {},
		...a ?? {}
	});
	let o = n$16(e.options), s = n$16(t.options);
	return (o || s) && (r.options = {
		...o ?? {},
		...s ?? {}
	}), r;
}
function i$18(e, t) {
	return r$11(e, t);
}
function a$16(e, t) {
	return {
		app: r$11(e.app, t.app),
		component: r$11(e.component, t.component)
	};
}
function o$18(e) {
	t$16 = a$16(t$16, e);
}
function c$16(e) {
	return i$18(t$16.app, e);
}
function l$13(e) {
	return i$18(t$16.component, e);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/watch/types.mjs
var e$19 = `version`;
function n$15() {
	return e$19;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/shallowRef.mjs
var r$10 = `__v_isShallow`;
function o$17(e) {
	return s$15(e) && e[r$10] === !0;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/traverse.mjs
function i$17(a, o = 1 / 0, s = /* @__PURE__ */ new Map()) {
	if (o <= 0 || !e$22(a)) return a;
	if (s$15(a)) return i$17(a.value, o - 1, s), a;
	if (a.__r_skip) return a;
	let c = s.get(a);
	if (c !== void 0 && c >= o) return a;
	s.set(a, o);
	let l = o - 1;
	if (Array.isArray(a) || a instanceof Map || a instanceof Set) return a.forEach((e) => i$17(e, l, s)), a;
	let u = F(a) && o !== 1 / 0 ? s$16(a) : a;
	for (let e in u) i$17(a[e], l, s);
	return a;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/watch/helpers.mjs
function c$15(e) {
	if (typeof e == `function`) return e();
	if (s$15(e)) return e.value;
	if (F(e)) return e;
	throw Error(`无效的 watch 源`);
}
function l$12(e) {
	let t = Array.isArray(e), n = !t && F(e), o = t ? e.some((e) => F(e)) : n, s = t ? e.some((e) => o$17(e)) : o$17(e), l;
	if (t) {
		let t = e;
		l = () => t.map((e) => c$15(e));
	} else if (typeof e == `function`) l = e;
	else if (s$15(e)) l = () => e.value;
	else if (n) l = () => e;
	else throw Error(`无效的 watch 源`);
	return {
		getter: l,
		hasReactiveSource: o,
		hasShallowSource: s,
		isMultiSource: t,
		isReactiveSource: n
	};
}
function u$13(e, t, i, a, c) {
	let l = i ? t.some((e) => F(e)) : a, u = c ?? l;
	if (u !== !0 && typeof u != `number`) return e;
	let d = typeof u == `number` ? u : u ? 1 / 0 : 0;
	return () => {
		let t = e(), a = n$15();
		return i && Array.isArray(t) ? t.map((e) => a === `version` && F(e) ? (g$4(e), e) : i$17(e, d)) : a === `version` && F(t) ? (g$4(t), t) : i$17(t, d);
	};
}
function d$12(n, r, i, a) {
	if (a) {
		a(n, i);
		return;
	}
	if (r === `sync`) {
		n();
		return;
	}
	if (r === `post`) {
		u$17(() => l$17(n));
		return;
	}
	i ? n() : l$17(n);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/reactivity/watch.mjs
function u$12(a, o, u = {}) {
	let d = s$20(), f = l$12(a), p = u$13(f.getter, a, f.isMultiSource, f.isReactiveSource, u.deep), m = u.deep === !0 || typeof u.deep == `number` || u.deep === void 0 && f.hasReactiveSource || f.hasShallowSource, h, g = (e) => {
		h = e;
	}, _ = f.isMultiSource ? [] : void 0, v, y = !1, b = 0, x = b, S, C = u.once ? (e, t, n) => {
		o(e, t, n), S();
	} : o, w = u.flush ?? `pre`, T = (e, t) => !f.isMultiSource || !Array.isArray(e) || !Array.isArray(t) ? !Object.is(e, t) : e.length !== t.length || e.some((e, n) => !Object.is(e, t[n])), E = (e, t = !1) => {
		if (!v.active || y || e !== b) return;
		let n = v();
		if (!t && !m && !T(n, _)) return;
		h?.();
		let a = s$20();
		c$21(d);
		try {
			C(n, _, g);
		} finally {
			c$21(a);
		}
		_ = n;
	}, D = () => E(x), O = (e) => {
		x = b, d$12(D, w, e, u.scheduler);
	};
	v = O$2(() => p(), {
		scheduler: () => {
			y || O(!1);
		},
		lazy: !0
	});
	let k = () => {
		h?.(), h = void 0, y$3(v);
	};
	return S = k, S.stop = k, S.pause = () => {
		y || (y = !0, b += 1);
	}, S.resume = () => {
		y && v.active && (y = !1, _ = v());
	}, u.immediate ? E(b, !0) : _ = v(), C$4(S), S;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/noSetData.mjs
var e$18 = Symbol(`wevu.noSetData`);
function t$15(t) {
	return Object.defineProperty(t, e$18, {
		value: !0,
		configurable: !0,
		enumerable: !1,
		writable: !1
	}), t;
}
function n$14(t) {
	return typeof t == `object` && !!t && t[e$18] === !0;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/capabilities.mjs
var e$17 = `__wevuScopedSlotMountState`;
function t$14(t) {
	return t[e$17];
}
var n$13 = {};
var r$9 = n$13;
function i$16(e, t) {
	n$13[e] !== t && (n$13[e] = t);
}
function a$15(e, t) {
	let r = n$13[e];
	if (!r) throw Error(`[wevu] runtime capability "${e}" is required by ${t}; install it before registration`);
	return r;
}
function o$16(e) {
	return e === !0 ? !0 : !e || typeof e != `object` || Array.isArray(e) ? !1 : e.enabled !== !1;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/teardown.mjs
function e$16(e) {
	let t, n = !1;
	for (let r of e) try {
		r();
	} catch (e) {
		n || (t = e, n = !0);
	}
	if (n) throw t;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/lifecycle/platform.mjs
var s$13 = !1;
var c$14;
function u$11(e) {
	c$14 = e;
}
function d$11(e) {
	c$14 === e && (c$14 = void 0);
}
function f$8(e) {
	let t = e.options;
	if (t && typeof t == `object`) return t;
	let r = s$21(), i = r[r.length - 1], a = i && typeof i == `object` ? i.options : void 0;
	return a && typeof a == `object` ? a : {};
}
function p$9() {
	if (s$13) return;
	s$13 = !0;
	let t = f$12();
	if (t && typeof t == `object`) {
		if (o$26(`pullDownRefreshApi`)) {
			let e = t.startPullDownRefresh;
			typeof e == `function` && (t.startPullDownRefresh = function(...t) {
				let n = e.apply(this, t);
				return c$14 && v$4(c$14, `onPullDownRefresh`, []), n;
			});
		}
		if (o$26(`pageScrollApi`) && t["__wevuPageScrollEventContract"] !== 1) {
			let e = t.pageScrollTo;
			typeof e == `function` && (t.pageScrollTo = function(t, ...n) {
				let r = c$14, o = e.apply(this, [t, ...n]);
				return r && i$23(r, () => {
					v$4(r, `onPageScroll`, [t ?? {}]);
				}), o;
			});
		}
	}
}
function m$9(n) {
	let { enableOnShareAppMessage: i, enableOnShareTimeline: a } = n;
	if (!i && !a || !o$26(`pageShareMenu`)) return;
	let o = f$12();
	if (!o || typeof o.showShareMenu != `function`) return;
	let s = m$12().shareTimelineRequiresShareAppMessage ? i || a : i;
	if (!s && !a) return;
	let c = [];
	s && c.push(`shareAppMessage`), a && c.push(`shareTimeline`);
	let l = [
		{
			withShareTicket: !0,
			menus: c
		},
		{ menus: c },
		a ? { withShareTicket: !0 } : void 0,
		a ? {} : void 0,
		void 0
	];
	for (let e of l) try {
		e === void 0 ? o.showShareMenu() : o.showShareMenu(e);
		break;
	} catch {}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/provideStore.mjs
var e$15 = /* @__PURE__ */ new Map();
function t$13(t, n) {
	e$15.set(t, n);
}
function n$12(t) {
	return e$15.has(t);
}
function r$8(t) {
	return e$15.get(t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/provideContext.mjs
function o$15(e) {
	return !!(e && typeof e == `object` && e["__wevuIsAppInstance"] === !0);
}
function s$12(e) {
	return Object.create(e ?? null);
}
function c$13(e) {
	if (!e) return s$12();
	let n = e[WEVU_APP_PROVIDES_KEY];
	if (n && typeof n == `object`) return n;
	let r = s$12();
	try {
		Object.defineProperty(e, WEVU_APP_PROVIDES_KEY, {
			value: r,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		e[WEVU_APP_PROVIDES_KEY] = r;
	}
	return r;
}
function l$11(e, t) {
	try {
		Object.defineProperty(e, WEVU_PROVIDES_KEY, {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		e[WEVU_PROVIDES_KEY] = t;
	}
}
function u$10(e) {
	let t = e[WEVU_PROVIDES_KEY];
	if (t && typeof t == `object`) return t;
	let n = e[WEVU_RUNTIME_APP_KEY], u = e["__wevuParentInstance"]?.["__wevuProvides"] ?? c$13(n), d = o$15(e) ? c$13(n) : s$12(u);
	return l$11(e, d), d;
}
function d$10(e) {
	return c$13(e);
}
function f$7(t, n, r, i = {}) {
	c$13(t)[n] = r, i.syncGlobal !== !1 && t$13(n, r);
}
function p$8(e, t, n) {
	let a = c$13(t), u = n?.["__wevuProvides"] ?? a, d = o$15(e) ? a : s$12(u);
	if (n) try {
		Object.defineProperty(e, WEVU_PARENT_INSTANCE_KEY, {
			value: n,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		e[WEVU_PARENT_INSTANCE_KEY] = n;
	}
	l$11(e, d);
}
function m$8(e, t) {
	let n = Object.getPrototypeOf(e);
	for (; n;) {
		if (n === t) return !0;
		n = Object.getPrototypeOf(n);
	}
	return !1;
}
function h$4(e, t) {
	let n = u$10(e), i = u$10(t);
	if (!(n === i || m$8(n, i) || m$8(i, n))) {
		Object.setPrototypeOf(i, n);
		try {
			Object.defineProperty(t, WEVU_PARENT_INSTANCE_KEY, {
				value: e,
				configurable: !0,
				enumerable: !1,
				writable: !0
			});
		} catch {
			t[WEVU_PARENT_INSTANCE_KEY] = e;
		}
	}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/provide.mjs
function c$12(e, n) {
	let r = s$20();
	r ? (u$10(r)[e] = n, o$15(r) && t$13(e, n)) : t$13(e, n);
}
function l$10(i, o) {
	let s = s$20();
	if (s) {
		let e = u$10(s);
		if (i in e) return e[i];
	}
	if (n$12(i)) return r$8(i);
	if (arguments.length >= 2) return o;
	let c = u$19();
	typeof c == `function` && c(`wevu.inject：未找到对应 key 的值：${String(i)}`);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/version.mjs
var t$12 = `7.4.0`;
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/setup.mjs
function e$12(e, t, n) {
	if (typeof e != `function`) return;
	let r = n?.runtime ?? {
		methods: Object.create(null),
		state: {},
		setupState: {},
		proxy: {},
		watch: () => () => {},
		bindModel: () => {}
	};
	return n && (n.runtime = r), e(t, {
		...n ?? {},
		runtime: r
	});
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/utils.mjs
function e$11(e) {
	return e ? e.charAt(0).toUpperCase() + e.slice(1) : ``;
}
var t$10 = /\B([A-Z])/g;
function n$11(e) {
	return e && e.replace(t$10, `-$1`).toLowerCase();
}
function r$7(e) {
	return e ? e.split(`.`).map((e) => e.trim()).filter(Boolean) : [];
}
function i$15(e, t) {
	return Object.prototype.hasOwnProperty.call(e, t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/setupTracking.mjs
function i$14(e) {
	if (Object.prototype.toString.call(e) !== `[object Object]`) return !1;
	let t = Object.getPrototypeOf(e);
	return t === null || t === Object.prototype;
}
function a$14(e) {
	return Array.isArray(e) || i$14(e);
}
function o$14(e) {
	if (Array.isArray(e)) return e;
	let t = [];
	for (let n of Object.keys(e)) {
		let r = Object.getOwnPropertyDescriptor(e, n);
		r && typeof r.get != `function` && t.push(r.value);
	}
	return t;
}
function s$11(e, t = /* @__PURE__ */ new WeakSet()) {
	return s$15(e) || F(e) ? !0 : !e || typeof e != `object` || t.has(e) || (t.add(e), !a$14(e)) ? !1 : o$14(e).some((e) => s$11(e, t));
}
function c$11(i, s = /* @__PURE__ */ new WeakSet()) {
	if (s$15(i)) {
		let e = i.value;
		F(e) && g$4(e), c$11(e, s);
		return;
	}
	if (F(i)) {
		g$4(i), c$11(s$16(i), s);
		return;
	}
	i && typeof i == `object` && !s.has(i) && a$14(i) && (s.add(i), o$14(i).forEach((e) => c$11(e, s)));
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/diff.mjs
function s$10(e) {
	if (Object.prototype.toString.call(e) !== `[object Object]`) return !1;
	let t = Object.getPrototypeOf(e);
	return t === null || t === Object.prototype;
}
function c$10(e, t) {
	if (!e || !t) return !1;
	let n = t;
	for (; n;) {
		if (e.has(n)) return !0;
		let t = n.lastIndexOf(`.`);
		if (t < 0) return !1;
		n = n.slice(0, t);
	}
	return !1;
}
function l$9(a, s, u, d, f, p, m, h, g, _) {
	let v = u$14(a);
	if (typeof v == `bigint`) {
		let e = Number(v);
		return Number.isSafeInteger(e) ? e : v.toString();
	}
	if (typeof v == `symbol`) return v.toString();
	if (typeof v == `function`) return h || c$10(g, _) ? v : void 0;
	if (typeof v != `object` || !v) return v;
	if (n$14(v)) return;
	let y = F(v), b = y ? s$16(v) : v, x = !!d && y;
	d && !x && (x = f?.get(b) ?? !s$11(b), f?.set(b, x));
	let S = x ? d : void 0;
	if (p <= 0 || m.keys <= 0) return b;
	if (S) {
		let e = j(b), n = S.get(b);
		if (n && n.version === e) return n.value;
	}
	if (u.has(b)) return;
	if (s.has(b)) return s.get(b);
	if (b instanceof Date) return b.getTime();
	if (b instanceof RegExp) return b.toString();
	if (b instanceof Map) {
		let e = [];
		return s.set(b, e), u.add(b), b.forEach((t, n) => {
			e.push([l$9(n, s, u, void 0, void 0, 1 / 0, { keys: 1 / 0 }, h, void 0, ``), l$9(t, s, u, void 0, void 0, 1 / 0, { keys: 1 / 0 }, h, void 0, ``)]);
		}), u.delete(b), e;
	}
	if (b instanceof Set) {
		let e = [];
		return s.set(b, e), u.add(b), b.forEach((t) => {
			e.push(l$9(t, s, u, void 0, void 0, 1 / 0, { keys: 1 / 0 }, h, void 0, ``));
		}), u.delete(b), e;
	}
	if (typeof ArrayBuffer < `u`) {
		if (b instanceof ArrayBuffer) return b.byteLength;
		if (ArrayBuffer.isView(b)) {
			let e = b;
			if (typeof e[Symbol.iterator] == `function`) {
				let t = [...e];
				return s.set(b, t), t.map((e) => l$9(e, s, u, void 0, void 0, 1 / 0, { keys: 1 / 0 }, h, void 0, ``));
			}
			let t = [...new Uint8Array(e.buffer, e.byteOffset, e.byteLength)];
			return s.set(b, t), t;
		}
	}
	if (b instanceof Error) return {
		name: b.name,
		message: b.message
	};
	if (Array.isArray(b)) {
		let e = [];
		s.set(b, e), u.add(b);
		let n = p - 1;
		for (let t = 0; t < b.length; t += 1) {
			let r = _ ? `${_}.${t}` : String(t), i = l$9(b[t], s, u, d, f, n, m, h, g, r);
			e[t] = i === void 0 ? null : i;
		}
		return u.delete(b), S && S.set(b, {
			version: j(b),
			value: e
		}), e;
	}
	let C = {};
	s.set(b, C), u.add(b);
	let w = p - 1;
	for (let e of Object.keys(b)) {
		if (--m.keys, m.keys <= 0) break;
		let t = _ ? `${_}.${e}` : e, n = l$9(b[e], s, u, d, f, w, m, h, g, t);
		n !== void 0 && (C[e] = n);
	}
	return u.delete(b), S && S.set(b, {
		version: j(b),
		value: C
	}), C;
}
function u$9(e, t = /* @__PURE__ */ new WeakMap(), n) {
	let r = n?._depth ?? (typeof n?.maxDepth == `number` ? Math.max(0, Math.floor(n.maxDepth)) : 1 / 0), i = n?._budget ?? (typeof n?.maxKeys == `number` ? { keys: Math.max(0, Math.floor(n.maxKeys)) } : { keys: 1 / 0 }), a = Array.isArray(n?.functionPaths) && n.functionPaths.length ? new Set(n.functionPaths) : void 0;
	return l$9(e, t, /* @__PURE__ */ new WeakSet(), n?.cache, n?.cacheEligibility, r, i, !!n?.includeFunctions, a, n?._path ?? ``);
}
function d$9(e, t, n) {
	if (e.length !== t.length) return !1;
	for (let r = 0; r < e.length; r++) if (!n(e[r], t[r])) return !1;
	return !0;
}
function f$6(e, t, n) {
	let r = Object.keys(e), i = Object.keys(t);
	if (r.length !== i.length) return !1;
	for (let i of r) if (!i$15(t, i) || !n(e[i], t[i])) return !1;
	return !0;
}
function p$7(e, t) {
	return Object.is(e, t) ? !0 : Array.isArray(e) && Array.isArray(t) ? d$9(e, t, p$7) : s$10(e) && s$10(t) ? f$6(e, t, p$7) : !1;
}
function m$7(e) {
	return e === void 0 ? null : e;
}
function h$3(e, t, n, r) {
	if (!p$7(e, t)) {
		if (s$10(e) && s$10(t)) {
			for (let i of Object.keys(t)) {
				if (!i$15(e, i)) {
					r[`${n}.${i}`] = m$7(t[i]);
					continue;
				}
				h$3(e[i], t[i], `${n}.${i}`, r);
			}
			for (let i of Object.keys(e)) i$15(t, i) || (r[`${n}.${i}`] = null);
			return;
		}
		if (Array.isArray(e) && Array.isArray(t)) {
			d$9(e, t, p$7) || (r[n] = m$7(t));
			return;
		}
		r[n] = m$7(t);
	}
}
function g$3(e, t, n) {
	let r = {}, i = n?.skipKeys;
	for (let n of Object.keys(t)) i?.has(n) || h$3(e[n], t[n], n, r);
	for (let n of Object.keys(e)) i?.has(n) || i$15(t, n) || (r[n] = null);
	return r;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/setData/snapshot.mjs
function i$13(e) {
	if (typeof e != `object` || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function o$13(e) {
	if (Array.isArray(e)) return e.map((e) => o$13(e));
	if (!i$13(e)) return e;
	let t = {};
	for (let n of Object.keys(e)) t[n] = o$13(e[n]);
	return t;
}
function c$9(e, t, r, a) {
	if (Object.is(e, t)) return !0;
	if (r <= 0) return !1;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n++) if (!c$9(e[n], t[n], r - 1, a)) return !1;
		return !0;
	}
	if (!i$13(e) || !i$13(t)) return !1;
	let o = Object.keys(e), s = Object.keys(t);
	if (o.length !== s.length) return !1;
	for (let i of o) if (--a.keys, a.keys <= 0 || !i$15(t, i) || !c$9(e[i], t[i], r - 1, a)) return !1;
	return !0;
}
function l$8(e, t, n, r, i) {
	let a = i?.cloneValue ?? !0, s = i?.clonedParents, c = t.split(`.`).filter(Boolean);
	if (!c.length) return;
	s?.add(e);
	let l = e;
	for (let e = 0; e < c.length - 1; e++) {
		let t = c[e], n = l[t];
		if (typeof n != `object` || !n) l[t] = {}, s?.add(l[t]);
		else if (s && !s.has(n)) {
			let e = Array.isArray(n) ? n.slice() : { ...n };
			l[t] = e, s.add(e);
		}
		l = l[t];
	}
	let u = c[c.length - 1];
	if (r === `delete`) try {
		delete l[u];
	} catch {
		l[u] = null;
	}
	else l[u] = a ? o$13(n) : n;
}
function u$8(n) {
	let { state: i, setupState: a, computedRefs: o, includeComputed: s, shouldIncludeKey: c, plainCache: l, plainCacheEligibility: u, toPlainMaxDepth: d, toPlainMaxKeys: f, includeFunctions: p = !1, functionPaths: m = [] } = n, h = /* @__PURE__ */ new WeakMap(), g = {}, _ = Number.isFinite(f) ? { keys: f } : void 0, v = F(i) ? s$16(i) : i, y = a && typeof a == `object` ? F(a) ? s$16(a) : a : void 0, b = Object.keys(v), x = y ? Object.keys(y) : [], S = s ? Object.keys(o) : [];
	for (let e of b) c(e) && (g[e] = u$9(v[e], h, {
		cache: l,
		cacheEligibility: u,
		maxDepth: d,
		includeFunctions: p,
		functionPaths: m,
		_budget: _,
		_path: e
	}));
	for (let e of x) c(e) && (g[e] = u$9(y[e], h, {
		cache: l,
		cacheEligibility: u,
		maxDepth: d,
		includeFunctions: p,
		functionPaths: m,
		_budget: _,
		_path: e
	}));
	for (let e of S) c(e) && (g[e] = u$9(o[e].value, h, {
		cache: l,
		cacheEligibility: u,
		maxDepth: d,
		includeFunctions: p,
		functionPaths: m,
		_budget: _,
		_path: e
	}));
	return g;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/setData/commitTracker.mjs
var t$9 = Promise.resolve();
function n$10(e) {
	return !(!e || typeof e != `object` && typeof e != `function` || typeof e.then != `function`);
}
function r$6(e) {
	try {
		return e instanceof Error ? e.message : String(e);
	} catch {
		return `<unprintable cause>`;
	}
}
function i$12(e, t, n) {
	let i = r$6(n), a = /* @__PURE__ */ Error(`[wevu] setData commit failed (${e === `adapter` ? `adapter failure` : `out-of-order completion`}, revision=${t.revision}, mode=${t.mode}, kind=${t.kind}): ${i}`);
	return a.cause = n, a;
}
function a$13(e) {
	let t = !1, r = !0, i = !1, a = !1, o = (n, r) => {
		t || (t = !0, e.settle(n, r));
	}, s = () => {
		if (r) {
			i = !0;
			return;
		}
		a || e.completion === `callback` && o(`committed`);
	};
	try {
		let t = e.invoke(s), c = n$10(t);
		if (a = c, r = !1, c) {
			t.then(() => o(`committed`), (e) => o(`failed`, e));
			return;
		}
		(e.completion === `return` || i) && o(`committed`);
	} catch (e) {
		r = !1, o(`failed`, e);
	}
}
function o$12(n) {
	let r = n.initialSnapshot ? o$13(n.initialSnapshot) : {}, o = new Set(Object.keys(r)), s = 0, c = 0, l, u;
	function d(e) {
		return e.inLedger ? (e.commitPromise || (e.commitPromise = new Promise((t) => {
			e.resolveCommit = t;
		})), e.commitPromise) : t$9;
	}
	let f = {
		preparedSnapshot: r,
		dispatchedSnapshot: r,
		committedSnapshot: r,
		revision: 0,
		committedRevision: 0,
		failedRevision: void 0,
		needsFullSnapshot: !1,
		get commitPromise() {
			return u ? d(u) : t$9;
		},
		disposed: !1
	}, p = (e, t, r) => {
		let a = i$12(e, t, r);
		try {
			n.onFailure({
				kind: e,
				revision: t.revision,
				committedRevision: f.committedRevision,
				mode: t.mode,
				cause: r,
				error: a,
				payloadKeys: t.payloadKeys,
				pendingPatchKeys: t.pendingPatchKeys
			});
		} catch {}
	}, m = (e) => {
		e.resolveCommit?.(), e.resolveCommit = void 0;
	}, h = (e) => {
		let t = l;
		for (; t;) {
			let n = t.next;
			if (t.inLedger = !1, t.next = void 0, m(t), t === e) {
				l = n, l || (u = void 0);
				return;
			}
			t = n;
		}
	}, g = () => {
		let e = l;
		for (; e;) {
			let t = e.next;
			e.inLedger = !1, e.next = void 0, e.physicalSettled || (e.status = `abandoned`), m(e), e = t;
		}
		l = void 0, u = void 0, s += 1, c = f.committedRevision;
	}, _ = () => {
		f.needsFullSnapshot = !0;
	}, v = (e, t, n) => {
		t.status = `failed`, f.failedRevision = t.revision, _(), g(), p(e, t, n);
	}, y = () => {
		for (; l?.status === `succeeded`;) {
			let e = l;
			f.committedSnapshot = e.snapshot, f.committedRevision = e.revision, l = e.next, e.inLedger = !1, e.next = void 0, m(e);
		}
		l || (u = void 0);
	}, b = (e) => {
		f.committedSnapshot = e.snapshot, f.committedRevision = e.revision, f.failedRevision = void 0, f.needsFullSnapshot = !1, h(e), y();
	}, x = (e, t, n) => {
		if (t === `failed`) {
			p(`adapter`, e, n);
			return;
		}
		t === `committed` && f.committedRevision > e.revision && (l && g(), _(), p(`out-of-order`, e, `revision ${e.revision} completed after committed revision ${f.committedRevision}`));
	}, S = (e, t, n) => {
		if (!(f.disposed || e.physicalSettled)) {
			if (e.physicalSettled = !0, !e.inLedger || e.epoch !== s) {
				x(e, t, n);
				return;
			}
			if (t === `abandoned`) {
				e.status = `abandoned`, _(), g();
				return;
			}
			if (t === `failed`) {
				v(`adapter`, e, n);
				return;
			}
			if (e.status = `succeeded`, c > e.revision) {
				v(`out-of-order`, e, `revision ${e.revision} completed after revision ${c}`);
				return;
			}
			if (c = e.revision, e.kind === `full`) {
				b(e);
				return;
			}
			y();
		}
	};
	return {
		state: f,
		dispatch: (t) => {
			if (f.disposed) return f.revision;
			let r = f.revision + 1;
			f.revision = r, f.preparedSnapshot = t.snapshot;
			let i = {
				revision: r,
				epoch: s,
				mode: t.mode,
				kind: t.kind,
				snapshot: t.snapshot,
				payloadKeys: Object.keys(t.payload).length,
				pendingPatchKeys: t.pendingPatchKeys,
				status: `dispatched`,
				physicalSettled: !1,
				inLedger: !0,
				next: void 0
			};
			u ? u.next = i : l = i, u = i, f.dispatchedSnapshot = t.snapshot;
			for (let e of Object.keys(t.payload)) o.add(e.split(`.`, 1)[0]);
			let c = (e, t) => {
				S(i, e, t);
			}, d = o$13(t.payload);
			if (typeof n.adapter.__wevu_dispatchSetData == `function`) try {
				n.adapter.__wevu_dispatchSetData(d, c);
			} catch (e) {
				c(`failed`, e);
			}
			else a$13({
				invoke: () => n.adapter.setData?.(d),
				completion: `return`,
				settle: c
			});
			return r;
		},
		createFullPayload: (e) => {
			let t = {}, n = new Set(Object.keys(e));
			for (let [n, r] of Object.entries(e)) t[n] = r === void 0 ? null : r;
			for (let e of o) n.has(e) || (t[e] = null);
			return t;
		},
		dispose: () => {
			f.disposed || (f.disposed = !0, g());
		}
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/emit.mjs
function n$9(t) {
	return !t || typeof t != `object` || Array.isArray(t) ? !1 : i$15(t, `bubbles`) || i$15(t, `composed`) || i$15(t, `capturePhase`);
}
function r$5(e) {
	return e.includes(`:`) ? e.replace(/:/g, `-`).toLowerCase() : n$11(e);
}
function i$11(e) {
	if (e.length === 0) return {
		detail: void 0,
		options: void 0
	};
	if (e.length === 1) return {
		detail: e[0],
		options: void 0
	};
	let t = e[e.length - 1];
	if (n$9(t)) {
		let n = e.slice(0, -1);
		return {
			detail: n.length <= 1 ? n[0] : n,
			options: t
		};
	}
	return {
		detail: e,
		options: void 0
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/nativeBridge.mjs
var e$10 = `__wevu_native_bridge__`;
function t$8(t) {
	try {
		Object.defineProperty(t, e$10, {
			value: !0,
			configurable: !1,
			enumerable: !1,
			writable: !1
		});
	} catch {
		t[e$10] = !0;
	}
}
function n$8(t) {
	return typeof t == `function` && !!t[e$10];
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/setupContext.mjs
var p$6 = [
	`triggerEvent`,
	`createSelectorQuery`,
	`createIntersectionObserver`,
	`setData`,
	`setUpdatePerformanceListener`
];
function m$6() {
	return Object.freeze(Object.create(null));
}
var h$2 = () => [];
function g$2(e) {
	return Array.isArray(e) ? [...new Set(e.filter((e) => typeof e == `string` && e.length > 0))] : !e || typeof e != `object` ? [] : Object.entries(e).filter(([, e]) => !!e).map(([e]) => e);
}
function _$4(e) {
	if (!i$15(e, "vueSlots")) return m$6();
	let t = () => g$2(e[WEVU_SLOT_NAMES_PROP]), n = (e) => typeof e == `string` && t().includes(e);
	return new Proxy(Object.create(null), {
		get(e, t) {
			if (n(t)) return h$2;
		},
		has(e, t) {
			return n(t);
		},
		ownKeys() {
			return t();
		},
		getOwnPropertyDescriptor(e, t) {
			if (n(t)) return {
				configurable: !0,
				enumerable: !0,
				value: h$2
			};
		},
		set() {
			return !1;
		},
		deleteProperty() {
			return !1;
		}
	});
}
function v$2(e, t) {
	let n = _$4(t);
	try {
		Object.defineProperty(e, "$slots", {
			value: n,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		e.$slots = n;
	}
	return n;
}
function y$2() {
	let e = (() => {});
	return e.stop = () => {}, e.pause = () => {}, e.resume = () => {}, e;
}
function b$1(e) {
	try {
		return t$15(e);
	} catch {
		return e;
	}
}
function x$2(t, n, r) {
	let i = t?.state, a = i && typeof i == `object` ? s$16(i) : void 0, o = t?.proxy, c = (e) => {
		let t = e[r];
		if (typeof t != `function`) return !1;
		if (n$8(t)) return !0;
		let i = n[r];
		return typeof i == `function` && t === i;
	}, u = (e) => !e || typeof e != `object` || e === n || e === o || c(e) ? !1 : typeof e[r] == `function`, d = a ? a[WEVU_NATIVE_INSTANCE_KEY] : void 0;
	if (u(d)) return d;
	let f = t?.instance;
	if (u(f)) return f;
}
function S$2(e, t, n) {
	t$8(n);
	try {
		Object.defineProperty(e, t, {
			value: n,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		e[t] = n;
	}
}
function C$3(i, o) {
	let c = i[WEVU_SETUP_CONTEXT_INSTANCE_KEY];
	if (c && typeof c == `object`) return c;
	let f = Object.create(null);
	try {
		Object.defineProperty(f, WEVU_NATIVE_INSTANCE_KEY, {
			configurable: !0,
			enumerable: !1,
			get() {
				let t = o?.state, n = (t && typeof t == `object` ? s$16(t) : void 0)?.[WEVU_NATIVE_INSTANCE_KEY];
				return n && typeof n == `object` ? n : i;
			}
		});
	} catch {
		f[WEVU_NATIVE_INSTANCE_KEY] = i;
	}
	let p = (e) => {
		let t = o?.proxy;
		if (t && Reflect.has(t, e)) return {
			found: !0,
			value: Reflect.get(t, e)
		};
		let n = o?.state?.["__wevuProps"] ?? i["__wevuProps"];
		return n && typeof n == `object` && i$15(n, e) ? {
			found: !0,
			value: Reflect.get(n, e)
		} : {
			found: !1,
			value: void 0
		};
	}, m = (e) => {
		let t = x$2(o, i, e);
		if (t) return t;
		let n = i[e];
		if (typeof n == `function` && !n$8(n)) return i;
	};
	S$2(f, `triggerEvent`, (...e) => {
		let [t, n, r] = e, i = m(`triggerEvent`);
		i && typeof i.triggerEvent == `function` && (e.length >= 3 ? i.triggerEvent(t, n, r) : i.triggerEvent(t, n));
	}), S$2(f, `createSelectorQuery`, () => {
		let e = m(`createSelectorQuery`);
		if (e && typeof e.createSelectorQuery == `function`) return e.createSelectorQuery();
		let a = f$12();
		if (!o$26(`globalCreateSelectorQuery`) || !a || typeof a.createSelectorQuery != `function`) return;
		let s = a.createSelectorQuery();
		if (!s || !m$12().selectorQueryScopeByIn || typeof s.in != `function`) return s;
		let c = x$2(o, i, `setData`) ?? i;
		return s.in(c);
	}), S$2(f, `createIntersectionObserver`, (e) => {
		let a = m(`createIntersectionObserver`);
		if (a && typeof a.createIntersectionObserver == `function`) return a.createIntersectionObserver(e ?? {});
		let s = f$12();
		if (!o$26(`globalCreateIntersectionObserver`) || !s || typeof s.createIntersectionObserver != `function`) return;
		let c = x$2(o, i, `setData`) ?? i;
		return m$12().intersectionObserverScopeByParameter ? s.createIntersectionObserver(c, e ?? {}) : s.createIntersectionObserver(e ?? {});
	}), S$2(f, `setData`, (e, t) => {
		let n = m(`setData`);
		if (n && typeof n.setData == `function`) return n.setData(e, t);
		let r = o?.adapter, i = typeof r?.setData == `function` ? r.setData(e) : void 0;
		return typeof t == `function` && t(), i;
	}), S$2(f, `setUpdatePerformanceListener`, (e) => {
		let t = m(`setUpdatePerformanceListener`);
		if (t && typeof t.setUpdatePerformanceListener == `function`) return t.setUpdatePerformanceListener(e);
	});
	let h = b$1(new Proxy(f, {
		get(e, t, n) {
			if (Reflect.has(e, t)) return Reflect.get(e, t, n);
			if (t === `$el`) return x$2(o, i, `setData`) ?? i;
			if (t === `renderRoot` || t === `shadowRoot`) return (x$2(o, i, `setData`) ?? i)[t];
			let r = p(t);
			if (r.found) return r.value;
			let a = i[t];
			return typeof a == `function` ? a.bind(i) : a;
		},
		has(e, t) {
			return Reflect.has(e, t) || p(t).found || t in i;
		},
		set(e, t, n) {
			return Reflect.has(e, t) ? (e[t] = n, !0) : (i[t] = n, !0);
		}
	}));
	try {
		Object.defineProperty(i, WEVU_SETUP_CONTEXT_INSTANCE_KEY, {
			value: h,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		i[WEVU_SETUP_CONTEXT_INSTANCE_KEY] = h;
	}
	return h;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/methodBridge.mjs
function i$10(e) {
	return !e || typeof e != `object` ? !1 : typeof e.triggerEvent == `function` || typeof e.createSelectorQuery == `function` || typeof e.createIntersectionObserver == `function` || typeof e.setData == `function`;
}
function a$12(t, n, r) {
	let i = n?.[r];
	if (typeof i != `function`) return !1;
	if (n$8(i)) return !0;
	let a = t?.proxy;
	return typeof a?.[r] == `function` && i === a[r];
}
function o$11(e, t) {
	if (!e || !i$10(t) || t === e.proxy) return;
	let r = t;
	if (a$12(e, r, `triggerEvent`) || a$12(e, r, `createSelectorQuery`) || a$12(e, r, `createIntersectionObserver`) || a$12(e, r, `setData`)) return;
	let o = e.state;
	if (o && typeof o == `object`) try {
		Object.defineProperty(o, WEVU_NATIVE_INSTANCE_KEY, {
			value: r,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		o[WEVU_NATIVE_INSTANCE_KEY] = r;
	}
}
function s$9(e, n) {
	try {
		let i = n.methods;
		for (let n of Object.keys(i)) p$6.includes(n) || typeof e[n] != `function` && (e[n] = function(...t) {
			let i = this["$wevu"] ?? e["$wevu"];
			o$11(i, this);
			let a = i?.methods?.[n];
			if (typeof a == `function`) return a.apply(i.proxy, t);
		});
	} catch {}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/layoutComponentMatcher.mjs
var e$9 = (e) => e.startsWith(`layouts/`);
function t$7(t) {
	let n = t.is;
	return typeof n == `string` && e$9(n, t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/provideContext.mjs
function o$10(t) {
	if (t$7(t)) return;
	let n = t[WEVU_PARENT_INSTANCE_KEY];
	if (n && typeof n == `object`) return n;
	let a = t.selectOwnerComponent;
	if (typeof a == `function`) try {
		let e = a.call(t);
		if (e && e !== t && typeof e == `object` && e.__wevu) return e;
	} catch {}
	let o = s$21(), s = o[o.length - 1];
	if (s && s !== t && typeof s == `object` && s.__wevu) return s;
}
function s$8(n) {
	if (!t$7(n)) return;
	let i = s$21(), a = i[i.length - 1];
	a && a !== n && typeof a == `object` && a.__wevu && h$4(n, a);
}
function c$8(e, t) {
	e[WEVU_RUNTIME_APP_KEY] = t, p$8(e, t, o$10(e)), s$8(e);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/utils.mjs
function l$7(e, t) {
	try {
		Object.defineProperty(e, WEVU_PROPS_KEY, {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		e[WEVU_PROPS_KEY] = t;
	}
}
function u$7(e, t) {
	try {
		Object.defineProperty(e, WEVU_SETUP_STATE_KEY, {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		e[WEVU_SETUP_STATE_KEY] = t;
	}
}
function d$8(e, t) {
	try {
		Object.defineProperty(e, WEVU_NATIVE_INSTANCE_KEY, {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		e[WEVU_NATIVE_INSTANCE_KEY] = t;
	}
}
function f$5(e, t) {
	try {
		Object.defineProperty(e, WEVU_RUNTIME_KEY, {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		e[WEVU_RUNTIME_KEY] = t;
	}
}
function p$5(e, t) {
	try {
		Object.defineProperty(e, "instance", {
			value: t,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		try {
			e.instance = t;
		} catch {}
	}
}
function m$5(e) {
	let t = e[WEVU_SETUP_CONTEXT_INSTANCE_KEY], r = t && typeof t.setData == `function` ? t.setData : void 0;
	if (typeof r == `function` && !n$8(r)) return r;
	let i = e.setData;
	if (typeof i == `function` && !n$8(i)) return i;
}
function h$1(e) {
	let t = e.route;
	if (typeof t == `string` && t) return t;
	let n = e.is;
	return typeof n == `string` && n ? n : `unknown`;
}
function g$1(e, t, n, r) {
	try {
		return r ? t.call(e, n, r) : t.call(e, n);
	} catch (t) {
		let n = h$1(e);
		throw Error(`[wevu] setData failed (${n}): ${t instanceof Error ? t.message : String(t)}`);
	}
}
function _$3(e, n, r) {
	let i = r ? new Set(r) : void 0, a = Object.keys(e);
	for (let r of a) if (!i$15(n, r) || i && !i.has(r)) try {
		delete e[r];
	} catch {}
	let o = r ?? Object.keys(n);
	for (let r of o) i$15(n, r) && (e[r] = n[r]);
}
function v$1(t, n, r = t.properties || {}) {
	let o = n && typeof n == `object` ? n[WEVU_PROPS_KEY] : void 0, s = o && typeof o == `object` ? o : f$9({});
	_$3(s, r, Array.isArray(t["__wevuPropKeys"]) ? t[WEVU_PROP_KEYS_KEY] : void 0), n && typeof n == `object` && l$7(n, s);
	try {
		Object.defineProperty(t, WEVU_PROPS_KEY, {
			value: s,
			configurable: !0,
			enumerable: !1,
			writable: !0
		});
	} catch {
		t[WEVU_PROPS_KEY] = s;
	}
	return s;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/setupResult.mjs
function i$9(e) {
	if (Object.prototype.toString.call(e) !== `[object Object]`) return !1;
	let t = Object.getPrototypeOf(e);
	return t === null || t === Object.prototype;
}
function a$11(e) {
	return typeof e != `object` || !e || s$15(e) || F(e) || Array.isArray(e) ? !0 : i$9(e);
}
function o$9(e, t) {
	if (!t) return e;
	for (let n of Object.keys(t)) {
		let r = Object.getOwnPropertyDescriptor(t, n);
		typeof r?.get == `function` && typeof r.set == `function` ? Object.defineProperty(e, n, r) : Object.defineProperty(e, n, {
			configurable: !0,
			enumerable: !0,
			value: t[n],
			writable: !0
		});
	}
	return e;
}
function s$7(e, t, n) {
	let r = Object.getOwnPropertyDescriptor(t, n);
	return typeof r?.get != `function` || typeof r.set != `function` ? !1 : (Object.defineProperty(e, n, r), !0);
}
function c$7(n, i, o, c) {
	let l = !!c?.includeFunctionsInState, u = c?.functionPropPaths, d = n?.methods ?? Object.create(null), f = n?.state ?? Object.create(null), p = n?.setupState ?? Object.create(null), m = F(f) ? s$16(f) : f, h = F(p) ? s$16(p) : p, g = !1;
	if (n && !n.methods) try {
		n.methods = d;
	} catch {}
	if (n && !n.state) try {
		n.state = f;
	} catch {}
	if (n && !n.setupState) try {
		n.setupState = p;
	} catch {}
	Object.keys(o).forEach((e) => {
		let t = o[e], c = s$7(h, o, e);
		if (typeof t == `function` && !c) {
			let r = (...e) => t.apply(n?.proxy ?? n, e);
			d[e] = r, f[e] = r, (l || u?.has(e)) && (p[e] = r), g = !0;
		} else {
			if (s$11(t) && n?.__wevu_trackSetupReactiveKey?.(e), f[e] = t, t === i || !a$11(t)) try {
				Object.defineProperty(m, e, {
					value: t,
					configurable: !0,
					enumerable: !1,
					writable: !0
				});
			} catch {}
			c || (p[e] = t);
		}
	}), n && (n.methods = n.methods ?? d, n.state = n.state ?? f, g && n.__wevu_touchSetupMethodsVersion?.());
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/setupPhase.mjs
var C$2 = 0;
function w$2(e, t) {
	let n, r = e, i = {
		proxy: {
			configurable: !0,
			enumerable: !1,
			value: t,
			writable: !1
		},
		$: {
			configurable: !0,
			enumerable: !1,
			value: e,
			writable: !1
		},
		uid: {
			configurable: !0,
			enumerable: !1,
			value: ++C$2,
			writable: !1
		},
		exposed: {
			configurable: !0,
			enumerable: !1,
			get: () => n
		}
	};
	for (let [e, t] of Object.entries(i)) try {
		Object.defineProperty(r, e, t);
	} catch {
		`value` in t && (r[e] = t.value);
	}
	let a = {
		$: {
			configurable: !0,
			enumerable: !1,
			value: e,
			writable: !1
		},
		$el: {
			configurable: !0,
			enumerable: !1,
			value: e,
			writable: !1
		}
	};
	for (let [e, n] of Object.entries(a)) try {
		Object.defineProperty(t, e, n);
	} catch {
		t[e] = n.value;
	}
	return (e) => {
		n = e;
	};
}
function T$2(e) {
	return e.startsWith(`__wv_`);
}
function E$2(C) {
	let { target: E, runtime: D, runtimeWithDefaults: O, runtimeState: k, runtimeProxy: A, setup: j } = C, N = v$1(E, k, E.properties || {}), P = f$9(Object.create(null)), F$4 = new Set(Array.isArray(E["__wevuPropKeys"]) ? E[WEVU_PROP_KEYS_KEY] : []), I = (e) => typeof k == `object` && !!k && i$15(k, e);
	(() => {
		let e = E.properties && typeof E.properties == `object` ? E.properties : void 0;
		for (let t of Object.keys(P)) (!e || !i$15(e, t) || T$2(t) || F$4.has(t) || I(t)) && delete P[t];
		if (e) for (let [t, n] of Object.entries(e)) T$2(t) || F$4.has(t) || I(t) || (P[t] = n);
	})();
	try {
		Object.defineProperty(E, WEVU_ATTRS_KEY, {
			value: P,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		E[WEVU_ATTRS_KEY] = P;
	}
	let L = C$3(E, O), R = w$2(E, L), z = v$2(k, N);
	u$7(k, O.setupState ?? Object.create(null));
	let V = b$1({
		props: N,
		runtime: O,
		state: k,
		proxy: A,
		bindModel: D.bindModel.bind(O),
		watch: D.watch.bind(O),
		instance: L,
		emit: (e, ...t) => {
			let { detail: n, options: r } = i$11(t), i = r$5(e);
			L.triggerEvent(i, n, r);
		},
		expose: (e) => {
			E[WEVU_EXPOSED_KEY] = e, R(e);
		},
		attrs: P,
		slots: z
	}), H = x$3(!0), U = s$20(), W = l$18(), G = () => {
		s$20() === E && l$18() === V && (u$18(W), c$21(U));
	};
	E[WEVU_EFFECT_SCOPE_KEY] = H, c$21(E), u$18(V);
	try {
		let e = H.run(() => e$12(j, N, V)), n = !1;
		if (e && typeof e == `object`) {
			let i = e, a = D.setupState && typeof D.setupState == `object` ? F(D.setupState) ? s$16(D.setupState) : D.setupState : Object.create(null);
			Object.keys(i).forEach((e) => {
				let t = i[e], r = s$7(a, i, e);
				if (typeof t == `function` && !r) {
					let r = (...e) => t.apply(D.proxy, e);
					D.methods[e] = r, D.state[e] = r, a[e] = r, n = !0;
				} else s$11(t) && D.__wevu_trackSetupReactiveKey?.(e), D.state[e] = t, r || (a[e] = t);
			});
		}
		n && D.__wevu_touchSetupMethodsVersion?.();
	} finally {
		G();
	}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance/setupSnapshot.mjs
function t$6(e) {
	return !!e && typeof e == `object` && !Array.isArray(e);
}
function n$7(r, i, a) {
	if (Array.isArray(r) && Array.isArray(i)) {
		r.splice(0, r.length, ...i);
		return;
	}
	if (!t$6(r) || !t$6(i)) return;
	let o = t$6(a) ? a : void 0;
	for (let e of Object.keys(o ?? {})) typeof o?.[e] != `function` && typeof r[e] != `function` && !Object.prototype.hasOwnProperty.call(i, e) && delete r[e];
	for (let [a, s] of Object.entries(i)) typeof r[a] != `function` && (s$15(r[a]) ? r[a].value = s : t$6(r[a]) && t$6(s) || Array.isArray(r[a]) && Array.isArray(s) ? n$7(r[a], s, o?.[a]) : r[a] = s);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/watch.mjs
function e$8(t, n, r) {
	if (typeof t == `function`) return {
		handler: t.bind(n.proxy),
		options: {}
	};
	if (typeof t == `string`) {
		let e = n.methods?.[t] ?? r[t];
		return typeof e == `function` ? {
			handler: e.bind(n.proxy),
			options: {}
		} : void 0;
	}
	if (!t || typeof t != `object`) return;
	let i = e$8(t.handler, n, r);
	if (!i) return;
	let a = { ...i.options };
	return t.immediate !== void 0 && (a.immediate = t.immediate), t.deep !== void 0 && (a.deep = t.deep), {
		handler: i.handler,
		options: a
	};
}
function t$5(e, t) {
	let n = t.split(`.`).map((e) => e.trim()).filter(Boolean);
	return n.length ? () => {
		let t = e;
		for (let e of n) {
			if (t == null) return t;
			t = t[e];
		}
		return t;
	} : () => e;
}
function n$6(n, r, i, a) {
	let o = [], s = n.proxy;
	for (let [c, l] of Object.entries(r)) {
		let r = e$8(l, n, i);
		if (!r) continue;
		let u = t$5(s, c), d = n.watch(u, r.handler, r.options), f = c.split(`.`)[0]?.trim();
		a?.deferMissingSourceBaseline && !r.options.immediate && f && !(f in s) && d.pause(), o.push(d);
	}
	return o;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/runtimeInstance.mjs
var x$1 = /* @__PURE__ */ new WeakMap();
function S$1(e, t = /* @__PURE__ */ new WeakMap()) {
	if (!e || typeof e != `object`) return e;
	if (t.has(e)) return t.get(e);
	if (Array.isArray(e)) {
		let n = [];
		t.set(e, n);
		for (let r of e) n.push(S$1(r, t));
		return n;
	}
	let n = {};
	t.set(e, n);
	for (let [r, i] of Object.entries(e)) n[r] = S$1(i, t);
	return n;
}
function _e(e, t) {
	let n = e ?? {};
	for (let [e, r] of Object.entries(t)) {
		let t;
		for (let r of Object.keys(n)) if (e.startsWith(`${r}.`)) {
			t = r;
			break;
		}
		if (t) {
			let i = { value: n[t] };
			l$8(i, `value.${e.slice(t.length + 1)}`, r, `set`, {
				cloneValue: !1,
				clonedParents: /* @__PURE__ */ new WeakSet()
			}), n[t] = i.value;
			continue;
		}
		let i = `${e}.`;
		for (let e of Object.keys(n)) e.startsWith(i) && delete n[e];
		n[e] = r;
	}
	return n;
}
function ve(e, t, n) {
	let r = e.data;
	if ((!r || typeof r != `object`) && (!n || !Object.keys(n).length)) return;
	let i = Array.isArray(t) && t.length ? new Set(t) : void 0, a = {};
	if (r && typeof r == `object`) for (let [e, t] of Object.entries(r)) i?.has(e) || (a[e] = S$1(t));
	if (n) for (let [e, t] of Object.entries(n)) i?.has(e) || (a[e] = S$1(t));
	return a;
}
function ye(e) {
	return !!e?.__wevuHasTemplateRuntimeBindings;
}
function C$1(e, n, c, l, u) {
	if (e.__wevu) return e.__wevu;
	let f = n.__wevuSetDataOptions, p = ye(n) ? a$15(`scopedSlots`, `mountRuntimeInstance(scoped-slot bindings)`) : void 0, m = p?.prepareMount(e), h = e.__wevuTemplateRefs;
	Array.isArray(h) && h.length && a$15(`templateRefs`, `mountRuntimeInstance(template refs)`);
	let _ = o$16(f?.highFrequencyWarning) ? a$15(`setDataHighFrequencyWarning`, `mountRuntimeInstance(setData.highFrequencyWarning)`) : void 0;
	c$8(e, n), b$1(e);
	let y = !!f?.suspendWhenHidden, C = typeof e.route == `string` && e.route ? `page:${e.route}` : typeof e.is == `string` && e.is ? `component:${e.is}` : `unknown-target`, w = _?.createMonitor({
		option: f?.highFrequencyWarning,
		targetLabel: C,
		isInPageScrollHook: () => Number(e["__wevuPageScrollHookDepth"] ?? 0) > 0
	}), T = !0, E = !u?.deferSetData, D = !1, O = 0, A, j, M, N = [], P = !(WEVU_HOST_COMMIT_PROMISE_KEY in e), F$3 = 0, I = !1, L, R, z, B, V = () => {
		!F$3 && !A && !R && (I = !1, L = void 0);
	}, H = () => {
		F$3 || A || (I ? B?.(L) : z?.(), R = void 0, z = void 0, B = void 0);
	}, be = () => {
		P && (F$3 += 1);
	}, U = (e = `committed`, t) => {
		P && !D && (e === `failed` && !I && (I = !0, L = t), --F$3, H());
	}, xe = (e) => U(`failed`, e);
	P && Object.defineProperty(e, "__wevuHostCommitPromise", {
		configurable: !0,
		enumerable: !1,
		get: () => !F$3 && !A ? I ? Promise.reject(L) : void 0 : (R ?? (R = new Promise((e, t) => {
			z = e, B = t;
		})), R)
	});
	let W = () => {
		m && r$9.scopedSlots?.refresh(e, m);
	}, G = () => {
		if (D) return;
		let t = e.__wevuTemplateRefs;
		if (!r$9.templateRefs && (!Array.isArray(t) || !t.length)) {
			P && U();
			return;
		}
		a$15(`templateRefs`, `mountRuntimeInstance(template ref completion)`).schedule(e, P ? U : void 0, e, P ? xe : void 0);
	}, Se = () => {
		m && p?.syncNativeOwnerId(e, m);
	}, Ce = (e) => {
		let t = {
			settle: e,
			next: void 0
		};
		M ? M.next = t : j = t, M = t;
	}, K = (e, t, n) => {
		let r = e, i = !0;
		for (; r;) {
			let e = r.next;
			r.next = void 0, t === `failed` && !i ? r.settle(`abandoned`) : r.settle(t, n), r = e, i = !1;
		}
	}, we = (t, n) => {
		let r = O;
		be(), W(), a$13({
			invoke: (n) => {
				let r = m$5(e);
				if (!r) {
					n();
					return;
				}
				return g$1(e, r, t, n);
			},
			completion: `callback`,
			settle: (e, t) => {
				if (!(D || r !== O)) {
					if (e !== `committed`) {
						U(e, t), n(e, t);
						return;
					}
					try {
						n(e, t);
					} catch (e) {
						throw U(`failed`, e), e;
					}
					G();
				}
			}
		});
	}, Te = () => {
		if (!A) return;
		let e = A, t = j, n = N;
		A = void 0, j = void 0, M = void 0, N = [], we(e, (e, r) => {
			if (e === `committed`) {
				try {
					for (let e of n) e();
				} finally {
					K(t, e, r);
				}
				return;
			}
			K(t, e, r);
		});
	}, Ee = () => {
		let e = j;
		A = void 0, j = void 0, M = void 0, N = [], K(e, `abandoned`), H();
	}, De = (e) => {
		V(), A = _e(A, e);
	}, q = {
		setData(t, n) {
			if (w?.(), !E || y && !T) {
				De(t), n && N.push(n), W();
				return;
			}
			W(), V(), be();
			let r = m$5(e);
			if (!r) {
				try {
					n?.();
				} catch (e) {
					throw U(`failed`, e), e;
				}
				G();
				return;
			}
			let i = !0, a = !1, o = !1, s = !1, c = (e) => {
				s || (s = !0, U(`failed`, e));
			}, l = () => {
				s || (s = !0, G());
			}, u = () => {
				try {
					n?.();
				} catch (e) {
					throw c(e), e;
				}
				if (i) {
					a = !0;
					return;
				}
				o || l();
			}, d;
			try {
				d = g$1(e, r, t, u);
			} catch (e) {
				throw c(e), e;
			}
			return i = !1, o = !!(d && typeof d.then == `function`), d && typeof d.then == `function` ? d.then(() => {
				l();
			}, (e) => {
				throw c(e), e;
			}) : (a && l(), d);
		},
		__wevu_dispatchSetData(e, t) {
			if (w?.(), D) {
				t(`abandoned`);
				return;
			}
			if (!E || y && !T) {
				De(e), Ce(t), W();
				return;
			}
			V(), we(e, t);
		},
		__wevu_enableSetData(e = !1) {
			if (E = !0, e) {
				Ee();
				return;
			}
			Te();
		},
		__wevu_setVisibility(e) {
			T = e, T && E && Te();
		},
		__wevu_disposeSetData() {
			D || (D = !0, O += 1, A = void 0, j = void 0, M = void 0, N = [], F$3 = 0, I = !1, L = void 0, H(), P && Reflect.deleteProperty(e, "__wevuHostCommitPromise"));
		}
	};
	Object.defineProperty(q, "__wevu_reportSetDataError", {
		configurable: !0,
		enumerable: !1,
		value: (t) => {
			v$4(e, `onError`, [t]);
		},
		writable: !1
	}), Object.defineProperty(q, "__wevu_targetLabel", {
		configurable: !0,
		enumerable: !1,
		value: C,
		writable: !1
	});
	let J = e.properties;
	J && typeof J == `object` && Object.defineProperty(q, "__wevu_initialProps", {
		configurable: !0,
		enumerable: !1,
		value: J,
		writable: !1
	}), Array.isArray(u?.snapshotOmitKeys) && u.snapshotOmitKeys.length && Object.defineProperty(q, "__wevu_snapshotOmitKeys", {
		configurable: !0,
		enumerable: !1,
		value: u.snapshotOmitKeys,
		writable: !1
	});
	let Y = ve(e, u?.snapshotOmitKeys);
	Y && Object.keys(Y).length && Object.defineProperty(q, "__wevu_initialSnapshot", {
		configurable: !0,
		enumerable: !1,
		value: Y,
		writable: !1
	}), m && Object.defineProperty(q, "__wevu_initialState", {
		configurable: !0,
		enumerable: !1,
		value: { ["__wvOwnerId"]: m.ownerId },
		writable: !1
	}), (u?.deferSetData || l || J && typeof J == `object` && Object.keys(J).length > 0) && Object.defineProperty(q, "__wevu_deferInitialSnapshot", {
		configurable: !0,
		enumerable: !1,
		value: !0,
		writable: !1
	});
	let X = n.mount(q);
	p$5(X, e);
	let Oe = X?.proxy ?? {}, Z = X?.state ?? {}, ke = X?.setupState ?? Object.create(null);
	Z && typeof Z == `object` && (f$5(Z, X), d$8(Z, e));
	let Ae = X?.computed ?? Object.create(null);
	if (!X?.methods) try {
		X.methods = Object.create(null);
	} catch {}
	let je = X?.methods ?? Object.create(null), Me = X?.watch ?? (() => y$2()), Ne = X?.bindModel ?? (() => {}), Q = {
		...X ?? {},
		state: Z,
		setupState: ke,
		proxy: Oe,
		methods: je,
		computed: Ae,
		watch: Me,
		bindModel: Ne,
		snapshot: X?.snapshot ?? (() => Object.create(null)),
		unmount: X?.unmount ?? (() => {})
	};
	Object.defineProperty(Q, "__wevu_initialRuntimeSnapshot", {
		configurable: !0,
		enumerable: !1,
		value: S$1(Z),
		writable: !1
	});
	let Pe = Q, Fe = {
		__wevu_flushSetupSnapshotSync: X.__wevu_flushSetupSnapshotSync,
		__wevu_touchSetupMethodsVersion: X.__wevu_touchSetupMethodsVersion,
		__wevu_trackSetupReactiveKey: X.__wevu_trackSetupReactiveKey,
		__wevu_cloneDispatchedSnapshot: X.__wevu_cloneDispatchedSnapshot,
		[WEVU_PROPS_DERIVED_KEYS_KEY]: X[WEVU_PROPS_DERIVED_KEYS_KEY]
	};
	for (let [e, t] of Object.entries(Fe)) t && Object.defineProperty(Q, e, {
		configurable: !0,
		enumerable: !1,
		value: t,
		writable: !0
	});
	Object.defineProperty(e, WEVU_PUBLIC_RUNTIME_KEY, {
		value: Q,
		configurable: !0,
		enumerable: !1,
		writable: !1
	}), e.__wevu = Q;
	v$2(Z, v$1(e, Z)), m && p?.attachMount(e, Q, m, !!u?.deferSetData), Se();
	let $ = c ? n$6(Q, c, e, { deferMissingSourceBaseline: !!l }) : [];
	if ($.length && (e["__wevuWatchStops"] = $), l) try {
		if (E$2({
			target: e,
			runtime: X,
			runtimeWithDefaults: Q,
			runtimeState: Z,
			runtimeProxy: Oe,
			setup: l
		}), typeof l$19()?.["__WEAPP_VITE_STATEFUL_HMR_BRIDGE__"]?.trackWevuComponent == `function`) {
			let e = {};
			for (let [n, r] of Object.entries(Q.setupState ?? {})) F(r) && (e[n] = S$1(r));
			x$1.set(Q, e);
		}
		u?.deferSetData || Pe.__wevu_flushSetupSnapshotSync?.(), u?.deferSetData || W();
		for (let e of $) e.resume();
	} catch (t) {
		try {
			k$1(e, { skipHooks: !0 });
		} catch {}
		throw t;
	}
	else !u?.deferSetData && e.properties && typeof e.properties == `object` && Object.keys(e.properties).length > 0 && (Pe.__wevu_flushSetupSnapshotSync?.(), W());
	return s$9(e, X), X;
}
function w$1(e, t, n) {
	for (let e of Reflect.ownKeys(t)) Reflect.has(n, e) || Reflect.getOwnPropertyDescriptor(t, e)?.configurable && Reflect.deleteProperty(t, e);
	for (let e of Reflect.ownKeys(n)) {
		let r = Reflect.getOwnPropertyDescriptor(n, e);
		if (r) try {
			Reflect.defineProperty(t, e, r);
		} catch {
			try {
				t[e] = n[e];
			} catch {}
		}
	}
	f$5(t.state, t);
	let r = x$1.get(n);
	return r && x$1.set(t, r), e.__wevu = t, Object.defineProperty(e, WEVU_PUBLIC_RUNTIME_KEY, {
		value: t,
		configurable: !0,
		enumerable: !1,
		writable: !1
	}), t;
}
function T$1(e, r, i) {
	let a = e.state, o = e.setupState, s = {};
	for (let e of Object.keys(r ?? {})) {
		if (!Object.prototype.hasOwnProperty.call(a, e)) continue;
		let r = o?.[e];
		if (!o || !Object.prototype.hasOwnProperty.call(o, e) || s$15(r) || F(r)) {
			if (i && Object.prototype.hasOwnProperty.call(i, e)) {
				s[e] = S$1(i[e]);
				continue;
			}
			s[e] = S$1(s$15(r) ? r.value : a[e]);
		}
	}
	return s;
}
function E$1(e, r) {
	let i = e.__wevu, a = i?.state, o = i?.setupState, s = r?.nativeData ?? e.data;
	if (!a || typeof a != `object` || !s || typeof s != `object`) return;
	let c = i?.__wevu_initialRuntimeSnapshot;
	for (let [e, i] of Object.entries(s)) if (e && e !== `undefined` && Object.prototype.hasOwnProperty.call(a, e)) try {
		let s = o?.[e], l = S$1(i);
		if (o && Object.prototype.hasOwnProperty.call(o, e) && (!r?.includeSetupState || !s$15(s) && !F(s)) || !r?.includeSetupState && c && Object.prototype.hasOwnProperty.call(c, e) && !c$9(a[e], c[e], 20, { keys: 1e4 }) || !r?.includeSetupState && c && !Object.prototype.hasOwnProperty.call(c, e)) continue;
		if (s$15(s)) {
			s.value = l;
			continue;
		}
		if (F(s) && l && typeof l == `object`) {
			n$7(s, l, r?.initialSetupState?.[e]);
			continue;
		}
		a[e] = l;
	} catch {}
}
function D$1(e, t) {
	let n = e.__wevu?.adapter;
	E$1(e, { includeSetupState: t?.rehydrateSetupState }), n?.__wevu_enableSetData?.(!0), e.__wevu?.__wevu_flushSetupSnapshotSync?.();
}
function O$1(e, t) {
	(e.__wevu?.adapter)?.__wevu_setVisibility?.(t);
}
function k$1(t, n) {
	let r = t.__wevu, a = t[WEVU_WATCH_STOPS_KEY], l = t[WEVU_EFFECT_SCOPE_KEY];
	e$16([
		() => {
			if (!n?.skipHooks && r && t["__wevuHooks"]?.["__wevuOnBeforeUnmount"]) {
				if (l?.active) l.run(() => v$4(t, WEVU_ON_BEFORE_UNMOUNT_HOOK));
				else {
					let n = x$3(!0);
					e$16([() => n.run(() => v$4(t, WEVU_ON_BEFORE_UNMOUNT_HOOK)), () => n.stop()]);
				}
			}
		},
		() => r$9.scopedSlots?.teardown(t),
		() => {
			Array.isArray(t.__wevuTemplateRefs) && t.__wevuTemplateRefs.length > 0 && a$15(`templateRefs`, `teardownRuntimeInstance(template refs)`).clear(t);
		},
		() => {
			!n?.skipHooks && r && t["__wevuHooks"] && v$4(t, `onUnload`, []);
		},
		() => {
			t["__wevuHooks"] && (t["__wevuHooks"] = void 0);
		},
		() => {
			if (Array.isArray(a)) for (let e of a) try {
				e();
			} catch {}
		},
		() => {
			t[WEVU_WATCH_STOPS_KEY] = void 0;
		},
		() => {
			l?.stop();
		},
		() => {
			t[WEVU_EFFECT_SCOPE_KEY] = void 0;
		},
		() => r?.unmount(),
		() => {
			(r?.adapter)?.__wevu_disposeSetData?.();
		},
		() => {
			delete t[WEVU_SETUP_CONTEXT_INSTANCE_KEY], delete t[WEVU_EXPOSED_KEY];
		},
		() => {
			delete t.__wevu;
		},
		() => {
			"$wevu" in t && delete t["$wevu"];
		}
	]);
}
function A(e, t, n, r, i) {
	let a = e.__wevu, o = a ? x$1.get(a) : void 0, s = a ? T$1(a, e.data, i?.stateSnapshot) : void 0;
	k$1(e, { skipHooks: !0 });
	let c = C$1(e, t, n, r, {
		deferSetData: !0,
		snapshotOmitKeys: i?.snapshotOmitKeys
	}), l = s ?? (i?.stateSnapshot ? T$1(c, i.stateSnapshot, i.stateSnapshot) : void 0);
	if (l) {
		let t = e.data;
		t && typeof t == `object` && Object.assign(t, S$1(l)), E$1(e, {
			includeSetupState: !0,
			nativeData: l,
			initialSetupState: o
		});
	}
	return !a || a === c ? c : w$1(e, a, c);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/app.mjs
var l$6 = `__wevuAppGlobalListeners`;
var u$6 = `__wevuOnMemoryWarningListener`;
function d$7(r) {
	let i = !!r[WEVU_HOOKS_KEY]?.onMemoryWarning;
	if (!o$26(`appMemoryWarningListener`)) {
		delete r[u$6];
		return;
	}
	let o = f$12(), s = o?.onMemoryWarning, c = o?.offMemoryWarning;
	if (typeof s != `function`) return;
	let l = r[u$6];
	if (typeof l == `function` && typeof c == `function`) try {
		c(l);
	} catch {}
	if (!i) {
		delete r[u$6];
		return;
	}
	let d = (e) => {
		v$4(r, `onMemoryWarning`, [e]);
	};
	r[u$6] = d, s(d);
}
function f$4(r, i) {
	var o;
	let { hookName: s, onApiName: c, offApiName: u, capabilityName: d, userHandler: f } = i, p = !!r[WEVU_HOOKS_KEY]?.[s], m = (o = r)[l$6] ?? (o[l$6] = Object.create(null)), h = m[s];
	if (!o$26(d)) {
		delete m[s], delete r[s];
		return;
	}
	let g = f$12(), _ = g?.[c], v = g?.[u];
	if (typeof h == `function` && typeof v == `function`) try {
		v(h);
	} catch {}
	if (!p && typeof f != `function`) {
		delete m[s];
		return;
	}
	let y = (...e) => {
		v$4(r, s, e), typeof f == `function` && f.apply(r, e);
	};
	r[s] = y, m[s] = y, typeof _ == `function` && _(y);
}
function p$4(e, t) {
	f$4(e, {
		hookName: `onError`,
		onApiName: `onError`,
		offApiName: `offError`,
		capabilityName: `appErrorListener`,
		userHandler: t.onError
	}), f$4(e, {
		hookName: `onPageNotFound`,
		onApiName: `onPageNotFound`,
		offApiName: `offPageNotFound`,
		capabilityName: `appPageNotFoundListener`,
		userHandler: t.onPageNotFound
	}), f$4(e, {
		hookName: `onUnhandledRejection`,
		onApiName: `onUnhandledRejection`,
		offApiName: `offUnhandledRejection`,
		capabilityName: `appUnhandledRejectionListener`,
		userHandler: t.onUnhandledRejection
	}), f$4(e, {
		hookName: `onThemeChange`,
		onApiName: `onThemeChange`,
		offApiName: `offThemeChange`,
		capabilityName: `appThemeChangeListener`,
		userHandler: t.onThemeChange
	});
}
function m$4(e, t, a, l, u) {
	if (typeof App != `function`) throw TypeError(`createApp 需要全局 App 构造器可用`);
	let f = Object.keys(t ?? {}), m = { ...u };
	m.globalData = m.globalData ?? {};
	let h = t ?? {}, g = h[WEVU_INLINE_MAP_KEY], _ = Object.prototype.hasOwnProperty.call(h, "__weapp_vite_inline_map") && g && typeof g == `object` && Object.keys(g).length > 0;
	!m["__weapp_vite_inline"] && _ && (m["__weapp_vite_inline"] = a$15(`inlineEvents`, `registerApp(inline event metadata)`).handler);
	let v = m.onLaunch, y = m.onError, b = m.onPageNotFound, x = m.onUnhandledRejection, S = m.onThemeChange;
	m.onLaunch = function(...t) {
		this[WEVU_IS_APP_INSTANCE_KEY] = !0, C$1(this, e, a, l), d$7(this), p$4(this, {
			onError: y,
			onPageNotFound: b,
			onUnhandledRejection: x,
			onThemeChange: S
		}), v$4(this, `onLaunch`, t), typeof v == `function` && v.apply(this, t);
	};
	let C = m.onShow;
	m.onShow = function(...e) {
		v$4(this, `onShow`, e), typeof C == `function` && C.apply(this, e);
	};
	let w = m.onHide;
	m.onHide = function(...e) {
		v$4(this, `onHide`, e), typeof w == `function` && w.apply(this, e);
	}, delete m.onError, delete m.onPageNotFound, delete m.onUnhandledRejection, delete m.onThemeChange;
	for (let e of f) {
		let t = m[e];
		m[e] = function(...n) {
			let r = this.__wevu, i, a = r?.methods?.[e];
			return a && (i = a.apply(r.proxy, n)), typeof t == `function` ? t.apply(this, n) : i;
		};
	}
	App(m);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/features.mjs
function e$7(e) {
	let { features: t, userOnSaveExitState: n, userOnPullDownRefresh: r, userOnReachBottom: i, userOnPageScroll: a, userOnRouteDone: o, userOnTabItemTap: s, userOnResize: c, userOnShareAppMessage: l, userOnShareTimeline: u, userOnAddToFavorites: d } = e, f = typeof r == `function` || !!t.enableOnPullDownRefresh, p = typeof i == `function` || !!t.enableOnReachBottom, m = typeof a == `function` || !!t.enableOnPageScroll, h = typeof o == `function` || !!t.enableOnRouteDone, g = !!t.enableOnRouteDoneFallback, _ = typeof s == `function` || !!t.enableOnTabItemTap, v = typeof c == `function` || !!t.enableOnResize, y = typeof u == `function` || !!t.enableOnShareTimeline, b = typeof l == `function` || !!t.enableOnShareAppMessage, x = typeof d == `function` || !!t.enableOnAddToFavorites, S = typeof n == `function` || !!t.enableOnSaveExitState, C = () => {};
	return {
		enableOnPullDownRefresh: f,
		enableOnReachBottom: p,
		enableOnPageScroll: m,
		enableOnRouteDone: h,
		enableOnRouteDoneFallback: g,
		enableOnTabItemTap: _,
		enableOnResize: v,
		enableOnShareAppMessage: b,
		enableOnShareTimeline: y,
		enableOnAddToFavorites: x,
		enableOnSaveExitState: S,
		effectiveOnSaveExitState: typeof n == `function` ? n : (() => ({ data: void 0 })),
		effectiveOnPullDownRefresh: typeof r == `function` ? r : C,
		effectiveOnReachBottom: typeof i == `function` ? i : C,
		effectiveOnPageScroll: typeof a == `function` ? a : C,
		effectiveOnRouteDone: typeof o == `function` ? o : C,
		effectiveOnTabItemTap: typeof s == `function` ? s : C,
		effectiveOnResize: typeof c == `function` ? c : C,
		effectiveOnShareAppMessage: typeof l == `function` ? l : C,
		effectiveOnShareTimeline: typeof u == `function` ? u : C,
		effectiveOnAddToFavorites: typeof d == `function` ? d : (() => ({}))
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/router/routeSync.mjs
var n$5 = /* @__PURE__ */ new Set();
function a$10(e) {
	for (let t of n$5) try {
		t(e);
	} catch {}
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/navigationLifecycle.mjs
var e$6;
function n$4(...t) {
	return e$6?.ensure(...t);
}
function r$4(t) {
	e$6?.cancel(t);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/lifecycle/optionalHooks.mjs
function a$9(a, o) {
	let { enableOnSaveExitState: s, enableOnPullDownRefresh: c, enableOnReachBottom: l, enableOnPageScroll: u, enableOnRouteDone: d, enableOnTabItemTap: f, enableOnResize: p, enableOnShareAppMessage: m, enableOnShareTimeline: h, enableOnAddToFavorites: g, effectiveOnSaveExitState: _, effectiveOnPullDownRefresh: v, effectiveOnReachBottom: y, effectiveOnPageScroll: b, effectiveOnRouteDone: x, effectiveOnTabItemTap: S, effectiveOnResize: C, effectiveOnShareAppMessage: w, effectiveOnShareTimeline: T, effectiveOnAddToFavorites: E, hasHook: D } = o;
	s && (a.onSaveExitState = function(...e) {
		let n = y$4(this, `onSaveExitState`, e);
		return n === void 0 ? _.apply(this, e) : n;
	}), c && (a.onPullDownRefresh = function(...t) {
		if (v$4(this, `onPullDownRefresh`, t), !D(this, `onPullDownRefresh`)) return v.apply(this, t);
	}), l && (a.onReachBottom = function(...t) {
		if (v$4(this, `onReachBottom`, t), !D(this, `onReachBottom`)) return y.apply(this, t);
	}), u && (a.onPageScroll = function(...e) {
		return a$23(this, e, D(this, `onPageScroll`) ? void 0 : b);
	}), d && (a.onRouteDone = function(...t) {
		if (!this["__wevuRouteDoneInTick"] && (this["__wevuRouteDoneInTick"] = !0, Promise.resolve().then(() => {
			this["__wevuRouteDoneInTick"] = !1;
		}), this["__wevuRouteDoneCalled"] = !0, v$4(this, `onRouteDone`, t), !D(this, `onRouteDone`))) return x.apply(this, t);
	}), f && (a.onTabItemTap = function(...t) {
		if (v$4(this, `onTabItemTap`, t), !D(this, `onTabItemTap`)) return S.apply(this, t);
	}), p && (a.onResize = function(...t) {
		if (v$4(this, `onResize`, t), !D(this, `onResize`)) return C.apply(this, t);
	}), m && (a.onShareAppMessage = function(...e) {
		let n = y$4(this, `onShareAppMessage`, e);
		return n === void 0 ? w.apply(this, e) : n;
	}), h && (a.onShareTimeline = function(...e) {
		let n = y$4(this, `onShareTimeline`, e);
		return n === void 0 ? T.apply(this, e) : n;
	}), g && (a.onAddToFavorites = function(...e) {
		let n = y$4(this, `onAddToFavorites`, e);
		return n === void 0 ? E.apply(this, e) : n;
	});
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/lifecycle.mjs
function y$1(y) {
	let { runtimeApp: b, watch: x, setup: S, userOnLoad: C, userOnUnload: w, userOnShow: T, userOnHide: E, userOnReady: D, isPage: O, enableOnSaveExitState: k, enableOnPullDownRefresh: A, enableOnReachBottom: j, enableOnPageScroll: M, enableOnRouteDone: N, enableOnRouteDoneFallback: P, enableOnTabItemTap: F, enableOnResize: I, enableOnShareAppMessage: L, enableOnShareTimeline: R, enableOnAddToFavorites: z, syncWevuPropsFromValues: B, effectiveOnSaveExitState: V, effectiveOnPullDownRefresh: H, effectiveOnReachBottom: U, effectiveOnPageScroll: W, effectiveOnRouteDone: G, effectiveOnTabItemTap: K, effectiveOnResize: q, effectiveOnShareAppMessage: J, effectiveOnShareTimeline: Y, effectiveOnAddToFavorites: X, hasHook: Z } = y, Q = (e) => {
		e.__wevu?.__wevu_flushSetupSnapshotSync?.();
	}, $ = {
		onLoad(...t) {
			if (this["__wevuOnLoadCalled"]) return;
			this[WEVU_ON_LOAD_CALLED_KEY] = !0;
			let n = () => {
				C$1(this, b, x, S);
				let n = t[0] && typeof t[0] == `object` ? t[0] : f$8(this);
				if (B?.(this, n), Q(this), D$1(this), O && m$9({
					enableOnShareAppMessage: L,
					enableOnShareTimeline: R
				}), v$4(this, `onLoad`, t), typeof C == `function`) return C.apply(this, t.length ? t : [n]);
			};
			return (O ? n$4(this, t[0], { onComplete: (e) => {
				e && n();
			} }) : void 0) || n();
		},
		onUnload(...e) {
			let t;
			return e$16([
				() => r$4(this),
				() => {
					O && d$11(this);
				},
				() => k$1(this),
				() => {
					typeof w == `function` && (t = w.apply(this, e));
				}
			]), t;
		},
		onShow(...t) {
			if (O && (p$9(), u$11(this), this["__wevuOnLoadCalled"] || $.onLoad.call(this, f$8(this)), B?.(this, f$8(this)), Q(this), m$9({
				enableOnShareAppMessage: L,
				enableOnShareTimeline: R
			}), this["__wevuRouteDoneCalled"] = !1), O$1(this, !0), O && a$10({
				page: this,
				source: `page`
			}), v$4(this, `onShow`, t), typeof T == `function`) return T.apply(this, t);
		},
		onHide(...t) {
			if (O && d$11(this), O$1(this, !1), v$4(this, `onHide`, t), typeof E == `function`) return E.apply(this, t);
		},
		onReady(...n) {
			if (O && (this["__wevuOnLoadCalled"] || $.onLoad.call(this, f$8(this)), B?.(this, f$8(this)), Q(this), m$9({
				enableOnShareAppMessage: L,
				enableOnShareTimeline: R
			})), !this["__wevuReadyCalled"]) {
				if (this["__wevuReadyCalled"] = !0, O && N && P) {
					let e = this;
					setTimeout(() => {
						e["__wevuRouteDoneCalled"] || $.onRouteDone?.call(e);
					}, 0);
				}
				let r = () => {
					v$4(this, `onReady`, n), typeof D == `function` && D.apply(this, n);
				}, i = () => {
					if (Array.isArray(this.__wevuTemplateRefs) && this.__wevuTemplateRefs.length > 0) {
						r$9.templateRefs?.schedule(this, r);
						return;
					}
					r();
				};
				O && n$4(this, void 0, {
					start: !1,
					onComplete: (e) => {
						e && i();
					}
				}) || i();
				return;
			}
			if (typeof D == `function`) return D.apply(this, n);
		}
	};
	return a$9($, {
		enableOnSaveExitState: k,
		enableOnPullDownRefresh: A,
		enableOnReachBottom: j,
		enableOnPageScroll: M,
		enableOnRouteDone: N,
		enableOnTabItemTap: F,
		enableOnResize: I,
		enableOnShareAppMessage: L,
		enableOnShareTimeline: R,
		enableOnAddToFavorites: z,
		effectiveOnSaveExitState: V,
		effectiveOnPullDownRefresh: H,
		effectiveOnReachBottom: U,
		effectiveOnPageScroll: W,
		effectiveOnRouteDone: G,
		effectiveOnTabItemTap: K,
		effectiveOnResize: q,
		effectiveOnShareAppMessage: J,
		effectiveOnShareTimeline: Y,
		effectiveOnAddToFavorites: X,
		hasHook: Z
	}), $;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/internal.mjs
function e$5(e, t, n) {
	let r = e[t];
	if (!r) throw Error(`计算属性 "${t}" 是只读的`);
	r(n);
}
function t$4(e) {
	if (e == null) return e;
	if (typeof e == `object`) {
		if (`detail` in e && e.detail && `value` in e.detail) return e.detail.value;
		if (`target` in e && e.target && `value` in e.target) return e.target.value;
	}
	return e;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/methods.mjs
function u$5(u) {
	let { userMethods: d, runtimeMethods: f } = u, p = { ...d }, m = f ?? {}, h = m[WEVU_INLINE_MAP_KEY], g = Object.prototype.hasOwnProperty.call(m, "__weapp_vite_inline_map") && h && typeof h == `object` && Object.keys(h).length > 0 ? a$15(`inlineEvents`, `createComponentMethods(inline event metadata)`) : r$9.inlineEvents;
	!p["__weapp_vite_inline"] && g && (p["__weapp_vite_inline"] = g.handler), p["__weapp_vite_model"] || (p["__weapp_vite_model"] = function(e) {
		let t = e?.currentTarget?.dataset?.wvModel ?? e?.target?.dataset?.wvModel;
		if (typeof t != `string` || !t) return;
		let r = this.__wevu;
		if (!r || typeof r.bindModel != `function`) return;
		let i = t$4(e);
		try {
			r.bindModel(t).update(i);
		} catch {}
	}), r$9.jsxIslands?.attachMethods(p), !p["__weapp_vite_owner"] && typeof f?.["__weapp_vite_owner"] == `function` && (p["__weapp_vite_owner"] = f["__weapp_vite_owner"]);
	let _ = Object.keys(f ?? {});
	function v(e) {
		let t = e.__wevu;
		if (t) return t;
		let n = e.$state;
		if (n && typeof n == `object`) return n[WEVU_RUNTIME_KEY];
	}
	function y(e, t) {
		if (e?.proxy === t) return;
		let n = e?.proxy, r = (e) => {
			let r = t[e];
			if (typeof r != `function`) return !1;
			let i = n?.[e];
			return typeof i == `function` && r === i;
		};
		if (r(`triggerEvent`) || r(`createSelectorQuery`) || r(`createIntersectionObserver`) || r(`setData`) || typeof t.triggerEvent != `function` && typeof t.createSelectorQuery != `function` && typeof t.createIntersectionObserver != `function` && typeof t.setData != `function`) return;
		let i = e?.state;
		if (i && typeof i == `object` && t.$state !== i) try {
			Object.defineProperty(i, WEVU_NATIVE_INSTANCE_KEY, {
				value: t,
				configurable: !0,
				enumerable: !1,
				writable: !0
			});
		} catch {
			i[WEVU_NATIVE_INSTANCE_KEY] = t;
		}
	}
	for (let e of _) {
		if (e === "__weapp_vite_inline_map" || e.startsWith("__weapp_vite_")) continue;
		let t = p[e];
		p[e] = function(...n) {
			let r = v(this);
			y(r, this);
			let i, a = r?.methods?.[e];
			if (a && (i = a.apply(r.proxy, n)), typeof t == `function`) {
				let e = t.apply(this, n);
				return e === void 0 ? i : e;
			}
			return i;
		};
	}
	return { finalMethods: p };
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/options.mjs
function i$8(e, t = /* @__PURE__ */ new WeakMap()) {
	if (!e || typeof e != `object`) return e;
	if (t.has(e)) return t.get(e);
	if (Array.isArray(e)) {
		let n = [];
		t.set(e, n);
		for (let r of e) n.push(i$8(r, t));
		return n;
	}
	let n = {};
	t.set(e, n);
	for (let [r, a] of Object.entries(e)) n[r] = i$8(a, t);
	return n;
}
function a$8(e) {
	let t = e.route;
	if (typeof t == `string` && t) return t;
	let n = e.is;
	return typeof n == `string` && n ? n : `unknown`;
}
function o$8(a) {
	let { methods: o = {}, lifetimes: s = {}, pageLifetimes: c = {}, options: l = {}, ...u } = a, d = u.onLoad, f = u.onUnload, p = u.onShow, m = u.onHide, h = u.onReady, g = u.onSaveExitState, _ = u.onPullDownRefresh, v = u.onReachBottom, y = u.onPageScroll, b = u.onRouteDone, x = u.onTabItemTap, S = u.onResize, C = u.onShareAppMessage, w = u.onShareTimeline, T = u.onAddToFavorites, E = u.features ?? {}, D = [
		d,
		f,
		p,
		m,
		h,
		g,
		_,
		v,
		y,
		b,
		x,
		S,
		C,
		w,
		T
	].some((e) => typeof e == `function`), O = i$15(u, `__wevu_isPage`) ? u.__wevu_isPage === !0 : Object.keys(E ?? {}).length > 0 || D, k = { ...u }, A = /* @__PURE__ */ new Set([
		`data`,
		`behaviors`,
		`relations`,
		`externalClasses`,
		`options`,
		`properties`,
		`observers`,
		`pureDataPattern`,
		`virtualHost`,
		`definitionFilter`,
		`export`,
		`__wevuTemplateRefs`,
		`__wevuLayoutHosts`,
		WEVU_PROPS_ALIASES_KEY,
		WEVU_PROPS_DERIVED_KEYS_KEY,
		`setupLifecycle`,
		`features`,
		`__wevu_isPage`
	]), j = [];
	for (let [e, t] of Object.entries(k)) A.has(e) || typeof t != `function` && (j.push([e, t]), delete k[e]);
	let M = (n) => {
		let r = a.name;
		typeof r == `string` && r && Object.defineProperty(n, "__wevuComponentName", {
			configurable: !0,
			enumerable: !1,
			value: r
		});
		for (let [t, r] of j) if (!i$15(n, t)) try {
			n[t] = i$8(r);
		} catch {}
	}, N = /* @__PURE__ */ new Set(/* @__PURE__ */ `data.export.definitionFilter.onLoad.onUnload.onShow.onHide.onReady.onSaveExitState.onPullDownRefresh.onReachBottom.onPageScroll.onRouteDone.onTabItemTap.onResize.onShareAppMessage.onShareTimeline.onAddToFavorites.beforeCreate.created.beforeMount.mounted.beforeUnmount.beforeDestroy.unmounted.destroyed`.split(`.`)), P = {};
	for (let [e, t] of Object.entries(k)) typeof t != `function` || N.has(e) || (P[e] = t, delete k[e]);
	let F = k.__wevuTemplateRefs;
	delete k.__wevuTemplateRefs;
	let I = k.__wevuLayoutHosts;
	delete k.__wevuLayoutHosts;
	let L = k[WEVU_PROPS_ALIASES_KEY];
	delete k[WEVU_PROPS_ALIASES_KEY];
	let R = k[WEVU_PROPS_DERIVED_KEYS_KEY];
	delete k[WEVU_PROPS_DERIVED_KEYS_KEY];
	let z = k.observers, B = k.setupLifecycle === `created` ? `created` : `attached`;
	delete k.setupLifecycle;
	let V = {};
	for (let e of [
		`beforeCreate`,
		`created`,
		`beforeMount`,
		`mounted`,
		`beforeUnmount`,
		`beforeDestroy`,
		`unmounted`,
		`destroyed`
	]) V[e] = k[e];
	delete k.features;
	for (let e of Object.keys(V)) delete k[e];
	return delete k.onLoad, delete k.onUnload, delete k.onShow, delete k.onHide, delete k.onReady, {
		userMethods: o,
		userLifetimes: s,
		userPageLifetimes: c,
		userOptions: l,
		restOptions: k,
		topLevelMethods: P,
		templateRefs: F,
		layoutHosts: I,
		propsAliases: L,
		propsDerivedKeys: R,
		userObservers: z,
		setupLifecycle: B,
		vueLifecycles: V,
		isPage: O,
		features: E,
		userOnLoad: d,
		userOnUnload: f,
		userOnShow: p,
		userOnHide: m,
		userOnReady: h,
		userOnSaveExitState: g,
		userOnPullDownRefresh: _,
		userOnReachBottom: v,
		userOnPageScroll: y,
		userOnRouteDone: b,
		userOnTabItemTap: x,
		userOnResize: S,
		userOnShareAppMessage: C,
		userOnShareTimeline: w,
		userOnAddToFavorites: T,
		applyExtraInstanceFields: M
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/snapshot.mjs
function n$3(n) {
	let r = t$14(n);
	r && r$9.scopedSlots?.refresh(n, r);
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/props.mjs
function d$6(d) {
	let { restOptions: f, propsAliases: p, propsDerivedKeys: m, userObservers: h } = d, g = f.properties && typeof f.properties == `object` ? Object.keys(f.properties) : [], _ = new Set(g), v = new Set(m ?? []), y = Object.entries(p ?? {}).filter(([e, t]) => e && t), b = /* @__PURE__ */ new Set([
		WEVU_SLOT_NAMES_PROP,
		WEVU_SLOT_OWNER_ID_PROP,
		WEVU_SLOT_SCOPE_KEY
	]), x = g.filter((e) => !b.has(e)), S = /* @__PURE__ */ new WeakMap(), C = (e) => e.startsWith(`__wv_`), w = (e) => {
		let t = e.__wevu?.[WEVU_PROPS_DERIVED_KEYS_KEY];
		if (t instanceof Set) for (let e of x) t.add(e);
	}, T = (t, n, r) => i$15(t, n) && Object.is(t[n], r) ? !1 : (t[n] = r, !0), E = (n, r, i) => b.has(r) && i$15(n, r) && c$9(n[r], i, 20, { keys: 1e4 }) ? !1 : T(n, r, i), D = (e, t, n) => {
		if (!b.has(t)) return;
		let r = !1, i = e.__wevu?.state;
		try {
			i && typeof i == `object` && E(i, t, n);
			let a = e.data;
			a && typeof a == `object` && (r = E(a, t, n));
		} catch {}
		if (r && typeof e.setData == `function`) try {
			e.setData({ [t]: n });
		} catch {}
	}, O = (t, n) => {
		if (!y.length) return;
		let r = t.__wevu, i = r?.setupState, a = r?.state;
		if (!i || typeof i != `object`) return;
		w(t);
		let o = S.get(t) ?? /* @__PURE__ */ new Set();
		S.set(t, o);
		for (let [t, r] of y) {
			if (i$15(i, t) && !o.has(t)) continue;
			let s = n[r];
			try {
				T(i, t, s), o.add(t);
			} catch {}
			if (a && typeof a == `object` && (!i$15(a, t) || o.has(t))) try {
				T(a, t, s);
			} catch {}
		}
	}, k = (t, n) => {
		if (!v.size) return;
		let r = t.__wevu?.setupState;
		if (!r || typeof r != `object`) return;
		w(t);
		let i = new Map(y);
		for (let t of v) {
			let a = i.get(t) ?? t;
			if (i$15(n, a)) try {
				T(r, t, n[a]);
			} catch {}
		}
	}, A = (e) => {
		try {
			Object.defineProperty(e, WEVU_PROP_KEYS_KEY, {
				value: g,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			e[WEVU_PROP_KEYS_KEY] = g;
		}
	}, j = (t) => {
		let i = t[WEVU_ATTRS_KEY];
		if (!i || typeof i != `object`) return;
		let a = (n) => {
			let r = t.__wevu?.state;
			return typeof r == `object` && !!r && i$15(r, n);
		}, o = t.properties, s = o && typeof o == `object` ? o : void 0, c = Object.keys(i);
		for (let t of c) if (!s || !i$15(s, t) || C(t) || _.has(t) || a(t)) try {
			delete i[t];
		} catch {}
		if (!s) {
			n$3(t);
			return;
		}
		for (let [e, t] of Object.entries(s)) if (!(C(e) || _.has(e) || a(e))) try {
			i[e] = t;
		} catch {}
		n$3(t);
	}, M = (t) => {
		let r = t[WEVU_PROPS_KEY], a = t.properties, s = t[WEVU_PENDING_PROP_VALUES_KEY];
		if (r && typeof r == `object` && a && typeof a == `object`) {
			let i = a, o = Object.keys(r);
			for (let t of o) if (!_.has(t) || !i$15(i, t)) try {
				delete r[t];
			} catch {}
			for (let n of g) {
				let a = s && i$15(s, n);
				if (!a && !i$15(i, n)) continue;
				let o = a ? s[n] : i[n];
				try {
					E(r, n, o);
				} catch {}
				D(t, n, o);
			}
			k(t, r), O(t, r), n$3(t);
		}
		s && delete t["__wevuPendingPropValues"], j(t);
	}, N = (t, r) => {
		if (!r || typeof r != `object`) return;
		let i = t[WEVU_PROPS_KEY];
		if (!i || typeof i != `object`) return;
		let a = !1;
		for (let n of g) if (i$15(r, n)) {
			try {
				a = E(i, n, r[n]) || a;
			} catch {}
			D(t, n, r[n]);
		}
		a && (k(t, i), O(t, i), n$3(t), j(t));
	}, P = (e, t, r) => {
		var a;
		let s = e[WEVU_PROPS_KEY];
		if (!s || typeof s != `object`) return;
		try {
			if (!E(s, t, r)) {
				D(e, t, r);
				return;
			}
		} catch {}
		D(e, t, r);
		let c = (a = e)["__wevuPendingPropValues"] ?? (a["__wevuPendingPropValues"] = Object.create(null));
		c[t] = r, k(e, s), O(e, s), n$3(e), j(e);
	}, F = {};
	if (g.length) for (let e of g) F[e] = function(t) {
		P(this, e, t);
	};
	let I = { ...h ?? {} };
	for (let [e, t] of Object.entries(F)) {
		let n = I[e];
		I[e] = typeof n == `function` ? function(...e) {
			n.apply(this, e), t.apply(this, e);
		} : t;
	}
	let L = I[`**`];
	return I[`**`] = function(...e) {
		typeof L == `function` && L.apply(this, e), M(this);
	}, {
		attachWevuPropKeys: A,
		directPropsDerivedKeys: x,
		syncWevuPropsFromInstance: M,
		syncWevuPropsFromValues: N,
		finalObservers: I
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/registerNativeDefinition.mjs
function i$7(e) {
	let n = l$19()?.[WEAPP_VITE_STATEFUL_HMR_BRIDGE_KEY];
	if (typeof n?.Component == `function`) {
		n.Component(e);
		return;
	}
	Component(e);
}
var o$7 = i$7;
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component/registerDefinition.mjs
function _$2(_) {
	let { runtimeApp: v, watch: y, setup: b, restOptions: x, pageLifecycleHooks: S, finalObservers: C, userLifetimes: w, userPageLifetimes: T, finalMethods: E, finalOptions: D, applyExtraInstanceFields: O, templateRefs: k, layoutHosts: A$2, attachWevuPropKeys: j, setupLifecycle: M, syncWevuPropsFromInstance: N, directPropsDerivedKeys: P, isPage: F, vueLifecycles: I, getRuntimeOwnerLabel: L, registerNative: R = !0 } = _, z = Array.isArray(k) && k.length > 0 ? k : void 0, B = /* @__PURE__ */ new WeakSet();
	z && a$15(`templateRefs`, `registerComponentDefinition(template refs)`);
	let V = Array.isArray(A$2) && A$2.length > 0 ? A$2 : void 0, H = V ? a$15(`layout`, `registerComponentDefinition(layout hosts)`) : void 0, ee = (e, t) => {
		if (z) {
			r$9.templateRefs?.schedule(e, t);
			return;
		}
		t?.();
	}, U = (e) => {
		let t = e.__wevu ?? e["$wevu"];
		if (t) return t;
		let n = e.$state;
		if (n && typeof n == `object`) return n[WEVU_RUNTIME_KEY];
	}, W = (e) => U(e)?.proxy || (r$9.scopedSlots?.resolveLifecycleProxy(e) ?? e), G = (e) => {
		let t = U(e);
		return t ? {
			runtime: t,
			mounted: !1
		} : (O(e), j(e), C$1(e, v, y, b, {
			deferSetData: !0,
			snapshotOmitKeys: P
		}), N(e), D$1(e), {
			runtime: U(e),
			mounted: !0
		});
	}, K = (e, t, n) => {
		let r = I[t];
		if (typeof r == `function`) return r.apply(W(e), n);
	}, q = (e, t) => {
		if (!F) {
			t();
			return;
		}
		n$4(e, void 0, {
			start: !1,
			onComplete: (e) => {
				e && t();
			}
		}) || t();
	}, J = (e) => {
		U(e) || typeof I.mounted != `function` || G(e).mounted && (K(e, `created`, []), K(e, `beforeMount`, []));
	}, Y = {}, X = (e) => {
		V && H?.attachHosts(V, e);
	}, Z = (e) => {
		F && H && H?.attachPageSetter(e);
	};
	if (F) for (let e of [
		`onPageScroll`,
		`onPullDownRefresh`,
		`onReachBottom`,
		`onShareAppMessage`,
		`onShareTimeline`,
		`onAddToFavorites`
	]) {
		let t = S[e];
		typeof t == `function` && typeof E[e] != `function` && (Y[e] = function(...e) {
			return t.apply(this, e);
		});
	}
	let Q = {
		...x,
		...F ? S : {},
		observers: C,
		lifetimes: {
			...w,
			created: function(...e) {
				B.add(this), O(this), j(this), z && r$9.templateRefs?.attachBindings(this, z), q(this, () => {
					if (K(this, `beforeCreate`, e), M === `created`) {
						try {
							C$1(this, v, y, b, {
								deferSetData: !0,
								snapshotOmitKeys: P
							});
						} catch (e) {
							let t = L(this);
							throw Error(`[wevu] mount runtime failed in created (${t}): ${e instanceof Error ? e.message : String(e)}`);
						}
						N(this), Z(this);
					}
					typeof w.created == `function` && w.created.apply(this, e);
				});
			},
			moved: function(...e) {
				v$4(this, `onMoved`, e), typeof w.moved == `function` && w.moved.apply(this, e);
			},
			attached: function(...e) {
				B.delete(this), O(this), j(this), z && !r$9.templateRefs?.hasBindings(this) && r$9.templateRefs?.attachBindings(this, z), q(this, () => {
					if (M !== `created` || !this.__wevu) try {
						C$1(this, v, y, b, {
							deferSetData: !0,
							snapshotOmitKeys: P
						});
					} catch (e) {
						let t = L(this);
						throw Error(`[wevu] mount runtime failed in attached (${t}): ${e instanceof Error ? e.message : String(e)}`);
					}
					N(this), K(this, `created`, e), K(this, `beforeMount`, e), Z(this), X(this), D$1(this), v$4(this, `onAttached`, e), typeof w.attached == `function` && w.attached.apply(this, e);
				});
			},
			ready: function(...e) {
				if (B.has(this)) return w.ready?.apply(this, e);
				if (!F || this["__wevuReadyCalled"] || !n$4(this, void 0, {
					start: !0,
					onComplete: (t) => {
						t && !this.__wevuInitialNavigationReady && (this.__wevuInitialNavigationReady = !0, Q.lifetimes.ready.call(this, ...e));
					}
				}) || this.__wevuInitialNavigationReady) {
					if (J(this), F && typeof S.onReady == `function`) {
						let t = !!this[WEVU_READY_CALLED_KEY];
						if (S.onReady.call(this, ...e), !t) {
							let t = () => K(this, `mounted`, e);
							n$4(this, void 0, {
								start: !1,
								onComplete: (e) => {
									e && t();
								}
							}) || t();
						}
						typeof w.ready == `function` && w.ready.apply(this, e);
						return;
					}
					if (!this["__wevuReadyCalled"]) {
						this[WEVU_READY_CALLED_KEY] = !0, N(this), r$9.templateRefs?.scheduleOwner(this), ee(this, () => {
							v$4(this, `onReady`, e), K(this, `mounted`, e), typeof w.ready == `function` && w.ready.apply(this, e);
						});
						return;
					}
					typeof w.ready == `function` && w.ready.apply(this, e);
				}
			},
			detached: function(...e) {
				if (F && typeof S.onUnload == `function`) {
					e$16([
						() => K(this, `beforeUnmount`, e),
						() => K(this, `beforeDestroy`, e),
						() => r$9.templateRefs?.scheduleOwner(this),
						() => v$4(this, `onDetached`, e),
						() => S.onUnload.call(this, ...e),
						() => {
							typeof w.detached == `function` && w.detached.apply(this, e);
						},
						() => K(this, `unmounted`, e),
						() => K(this, `destroyed`, e)
					]);
					return;
				}
				e$16([
					() => K(this, `beforeUnmount`, e),
					() => K(this, `beforeDestroy`, e),
					() => r$9.templateRefs?.scheduleOwner(this),
					() => v$4(this, `onDetached`, e),
					() => {
						V && H?.detachHosts(V, this);
					},
					() => k$1(this),
					() => K(this, `unmounted`, e),
					() => K(this, `destroyed`, e),
					() => {
						typeof w.detached == `function` && w.detached.apply(this, e);
					}
				]);
			},
			error: function(...e) {
				v$4(this, `onError`, e), typeof w.error == `function` && w.error.apply(this, e);
			}
		},
		pageLifetimes: {
			...T,
			show: function(...e) {
				if (F && typeof S.onShow == `function`) {
					S.onShow.call(this, ...e), typeof T.show == `function` && T.show.apply(this, e);
					return;
				}
				O$1(this, !0), v$4(this, `onShow`, e), typeof T.show == `function` && T.show.apply(this, e);
			},
			hide: function(...e) {
				if (F && typeof S.onHide == `function`) {
					S.onHide.call(this, ...e), typeof T.hide == `function` && T.hide.apply(this, e);
					return;
				}
				O$1(this, !1), v$4(this, `onHide`, e), typeof T.hide == `function` && T.hide.apply(this, e);
			},
			resize: function(...e) {
				if (F && typeof S.onResize == `function`) {
					S.onResize.call(this, ...e), typeof T.resize == `function` && T.resize.apply(this, e);
					return;
				}
				v$4(this, `onResize`, e), typeof T.resize == `function` && T.resize.apply(this, e);
			},
			routeDone: function(...e) {
				if (F && typeof S.onRouteDone == `function`) {
					S.onRouteDone.call(this, ...e), typeof T.routeDone == `function` && T.routeDone.apply(this, e);
					return;
				}
				v$4(this, `onRouteDone`, e), typeof T.routeDone == `function` && T.routeDone.apply(this, e);
			}
		},
		methods: {
			...Y,
			...E,
			[WEVU_RESOLVE_PUBLIC_INSTANCE_METHOD]: function() {
				let e = G(this);
				return e.mounted && (K(this, `created`, []), K(this, `beforeMount`, [])), e.runtime?.proxy;
			}
		},
		options: D
	};
	if (!R) return Q;
	let $ = l$19()?.[WEAPP_VITE_STATEFUL_HMR_BRIDGE_KEY];
	if (typeof $?.trackWevuComponent == `function`) {
		let e = $.trackWevuComponent(Q, (e, t) => {
			A(e, v, y, b, {
				snapshotOmitKeys: P,
				stateSnapshot: t
			}), N(e), Z(e), X(e), D$1(e, { rehydrateSetupState: !0 });
		}, (e) => {
			e$16([() => V && H?.detachHosts(V, e), () => k$1(e, { skipHooks: !0 })]);
		});
		return $.isApplying() || o$7(e, F), e;
	}
	return o$7(Q, F), Q;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/register/component.mjs
function c$6(c, l, u, d, f, p = {}) {
	let { userMethods: m, userLifetimes: h, userPageLifetimes: g, userOptions: _, restOptions: v, topLevelMethods: y, templateRefs: b, layoutHosts: x, propsAliases: S, propsDerivedKeys: C, userObservers: w, setupLifecycle: T, vueLifecycles: E, isPage: D, features: O, userOnLoad: k, userOnUnload: A, userOnShow: j, userOnHide: M, userOnReady: N, userOnSaveExitState: P, userOnPullDownRefresh: F, userOnReachBottom: I, userOnPageScroll: L, userOnRouteDone: R, userOnTabItemTap: z, userOnResize: B, userOnShareAppMessage: V, userOnShareTimeline: H, userOnAddToFavorites: U, applyExtraInstanceFields: W } = o$8(f), { enableOnPullDownRefresh: G, enableOnReachBottom: K, enableOnPageScroll: te, enableOnRouteDone: q, enableOnRouteDoneFallback: J, enableOnTabItemTap: Y, enableOnResize: X, enableOnShareAppMessage: Z, enableOnShareTimeline: Q, enableOnAddToFavorites: ne, enableOnSaveExitState: re, effectiveOnSaveExitState: ie, effectiveOnPullDownRefresh: ae, effectiveOnReachBottom: oe, effectiveOnPageScroll: se, effectiveOnRouteDone: ce, effectiveOnTabItemTap: le, effectiveOnResize: ue, effectiveOnShareAppMessage: de, effectiveOnShareTimeline: fe, effectiveOnAddToFavorites: pe } = e$7({
		features: O,
		userOnSaveExitState: P,
		userOnPullDownRefresh: F,
		userOnReachBottom: I,
		userOnPageScroll: L,
		userOnRouteDone: R,
		userOnTabItemTap: z,
		userOnResize: B,
		userOnShareAppMessage: V,
		userOnShareTimeline: H,
		userOnAddToFavorites: U
	}), me = (e, t) => {
		let n = e[WEVU_HOOKS_KEY];
		if (!n) return !1;
		let r = n[t];
		return r ? Array.isArray(r) ? r.length > 0 : typeof r == `function` : !1;
	};
	{
		let e = v.export;
		v.export = function() {
			let t = this["__wevuExposed"] ?? {}, n = typeof e == `function` ? e.call(this) : {};
			return n && typeof n == `object` && !Array.isArray(n) ? {
				...t,
				...n
			} : n ?? t;
		};
	}
	let he = {
		multipleSlots: _.multipleSlots ?? !0,
		..._
	}, { attachWevuPropKeys: ge, directPropsDerivedKeys: _e, syncWevuPropsFromInstance: ve, syncWevuPropsFromValues: $, finalObservers: ye } = d$6({
		restOptions: v,
		propsAliases: S,
		propsDerivedKeys: C,
		userObservers: w
	}), { finalMethods: be } = u$5({
		userMethods: {
			...y,
			...m
		},
		runtimeMethods: l
	});
	return _$2({
		runtimeApp: c,
		watch: u,
		setup: d,
		restOptions: v,
		pageLifecycleHooks: y$1({
			runtimeApp: c,
			watch: u,
			setup: d,
			userOnLoad: k,
			userOnUnload: A,
			userOnShow: j,
			userOnHide: M,
			userOnReady: N,
			isPage: D,
			enableOnSaveExitState: re,
			enableOnPullDownRefresh: G,
			enableOnReachBottom: K,
			enableOnPageScroll: te,
			enableOnRouteDone: q,
			enableOnRouteDoneFallback: J,
			enableOnTabItemTap: Y,
			enableOnResize: X,
			enableOnShareAppMessage: Z,
			enableOnShareTimeline: Q,
			enableOnAddToFavorites: ne,
			syncWevuPropsFromValues: $,
			effectiveOnSaveExitState: ie,
			effectiveOnPullDownRefresh: ae,
			effectiveOnReachBottom: oe,
			effectiveOnPageScroll: se,
			effectiveOnRouteDone: ce,
			effectiveOnTabItemTap: le,
			effectiveOnResize: ue,
			effectiveOnShareAppMessage: de,
			effectiveOnShareTimeline: fe,
			effectiveOnAddToFavorites: pe,
			hasHook: me
		}),
		finalObservers: ye,
		userLifetimes: h,
		userPageLifetimes: g,
		finalMethods: be,
		finalOptions: he,
		applyExtraInstanceFields: W,
		templateRefs: b,
		layoutHosts: x,
		attachWevuPropKeys: ge,
		setupLifecycle: T,
		syncWevuPropsFromInstance: ve,
		syncWevuPropsFromValues: $,
		directPropsDerivedKeys: _e,
		isPage: D,
		vueLifecycles: E,
		getRuntimeOwnerLabel: a$8,
		registerNative: p.registerNative
	});
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/bindingManifest.mjs
var e$4 = {
	"exact-path": !0,
	"snapshot-fallback": !0,
	"top-level": !0
};
function t$3(e) {
	return Array.isArray(e) && e.every((e) => typeof e == `string`);
}
function n$2(e) {
	return typeof e == `number` && Number.isFinite(e) && Number.isInteger(e);
}
function r$3(e) {
	if (!e || typeof e != `object`) return !1;
	let t = e;
	return n$2(t.offset) && t.offset >= 0 && n$2(t.line) && t.line >= 1 && n$2(t.column) && t.column >= 1;
}
function i$6(e) {
	if (!e || typeof e != `object`) return !1;
	let t = e, n = t.start, i = t.end;
	return r$3(n) && r$3(i) && i.offset >= n.offset;
}
function a$7(e) {
	return Object.values(e).every((e) => e === !0);
}
function o$6(n) {
	if (!n || typeof n != `object`) return !1;
	let r = n;
	return typeof r.id == `string` && r.id.length > 0 && typeof r.outputPath == `string` && r.outputPath.length > 0 && (r.sourceFile === void 0 || typeof r.sourceFile == `string` && r.sourceFile.length > 0) && (r.updateMode === void 0 || typeof r.updateMode == `string` && e$4[r.updateMode] === !0) && (r.sourceRoots === void 0 || t$3(r.sourceRoots)) && (r.sourceLocation === void 0 || i$6(r.sourceLocation));
}
function s$6(e) {
	if (!e || typeof e != `object`) return;
	let t = e;
	if (t.version === 1 && typeof t.sourceFile == `string` && Array.isArray(t.bindings) && t.bindings.every(o$6) && (t.features === void 0 || t.features && typeof t.features == `object` && !Array.isArray(t.features) && a$7(t.features))) return t;
}
function c$5(e, t) {
	return e?.bindings.some((e) => e.outputPath === t) ?? !1;
}
function l$5(e) {
	return e.replace(/\[(?:'([^']+)'|"([^"]+)"|([^\]]+))\]/g, (e, t, n, r) => `.${t ?? n ?? r}`).replace(/^\./, ``);
}
function u$4(e) {
	return l$5(e).split(`.`, 1)[0] ?? ``;
}
function d$5(e, t) {
	let n = l$5(e), r = l$5(t);
	return n === r || n.startsWith(`${r}.`) || r.startsWith(`${n}.`);
}
function f$3(e) {
	return e.updateMode ?? `exact-path`;
}
function p$3(e, t) {
	if (!t) return !1;
	let n = f$3(e);
	if (n === `snapshot-fallback` && e.outputPath === `*`) return !0;
	if (n === `exact-path`) return d$5(e.outputPath, t);
	let r = u$4(t);
	return u$4(e.outputPath) === r || n === `snapshot-fallback` && (e.sourceRoots ?? []).some((e) => u$4(e) === r);
}
function m$3(e, t, n = !1) {
	let r = [...t], i = /* @__PURE__ */ new Set(), a = [];
	for (let t of e.bindings) {
		if (i.has(t.id)) continue;
		let o = f$3(t);
		if (!(r.length > 0 ? r.some((e) => p$3(t, e)) : n && o === `snapshot-fallback`)) continue;
		i.add(t.id);
		let s = {
			id: t.id,
			outputPath: t.outputPath,
			updateMode: o,
			sourceFile: t.sourceFile ?? e.sourceFile
		};
		t.sourceLocation && (s.sourceLocation = t.sourceLocation), a.push(s);
	}
	return a;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/bindModel.mjs
function a$6(e, t, n) {
	let r = e;
	for (let e = 0; e < t.length - 1; e++) {
		let n = t[e];
		(r[n] == null || typeof r[n] != `object`) && (r[n] = {}), r = r[n];
	}
	r[t[t.length - 1]] = n;
}
function o$5(t, n, r, o, s, c) {
	if (!s.length) return;
	let [l, ...u] = s;
	if (!u.length) {
		if (r[l]) e$5(o, l, c);
		else {
			let r = n && Object.prototype.hasOwnProperty.call(n, l) ? n : t, i = r[l];
			s$15(i) ? i.value = c : r[l] = c;
		}
		return;
	}
	if (r[l]) {
		e$5(o, l, c);
		return;
	}
	let d = n && Object.prototype.hasOwnProperty.call(n, l) ? n : t;
	(d[l] == null || typeof d[l] != `object`) && (d[l] = {}), a$6(d[l], u, c);
}
function s$5(e, t) {
	return t.reduce((e, t) => e == null ? e : e[t], e);
}
function c$4(e) {
	return t$4(e);
}
function l$4(e, r, i, a, l) {
	return (u, d) => {
		let f = r$7(u);
		if (!f.length) throw Error(`bindModel 需要非空路径`);
		let p = () => s$5(e, f), m = (e) => {
			o$5(r, l, i, a, f, e);
		}, h = {
			event: `input`,
			valueProp: `value`,
			parser: c$4,
			formatter: (e) => e,
			...d
		};
		return {
			get value() {
				return p();
			},
			set value(e) {
				m(e);
			},
			update(e) {
				m(e);
			},
			model(e) {
				let n = {
					...h,
					...e
				}, r = `on${e$11(n.event)}`, i = (e) => {
					let t = n.parser(e);
					m(t);
				};
				return {
					[n.valueProp]: n.formatter(p()),
					[r]: i
				};
			}
		};
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/computed.mjs
function i$5(i) {
	let a = Object.create(null), o = Object.create(null), s = /* @__PURE__ */ new Set();
	return {
		computedRefs: a,
		computedSetters: o,
		dirtyComputedKeys: s,
		createTrackedComputed: (a, o, c) => {
			let l, u = !0, d, f = {
				get value() {
					return u && (l = d(), u = !1), A$1(f, `value`), l;
				},
				set value(e) {
					if (!c) throw Error(`计算属性是只读的`);
					c(e);
				}
			};
			return o$19(f), d = k$2(o, {
				lazy: !0,
				scheduler: () => {
					u || (u = !0, i.setDataStrategy === `patch` && i.includeComputed && s.add(a), M$1(f, `value`));
				}
			}), f;
		},
		computedProxy: new Proxy({}, {
			get(e, t) {
				if (typeof t == `string` && a[t]) return a[t].value;
			},
			has(e, t) {
				return typeof t == `string` && !!a[t];
			},
			ownKeys() {
				return Object.keys(a);
			},
			getOwnPropertyDescriptor(e, t) {
				if (typeof t == `string` && a[t]) return {
					configurable: !0,
					enumerable: !0,
					value: a[t].value
				};
			}
		})
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/context.mjs
function b(b) {
	let { state: x, setupState: S, computedDefs: C, methodDefs: w, appConfig: T, includeComputed: E, setDataStrategy: D } = b, O = {}, { computedRefs: k, computedSetters: A, dirtyComputedKeys: j, createTrackedComputed: M, computedProxy: N } = i$5({
		includeComputed: E,
		setDataStrategy: D
	}), P = l$14(0), F = Object.create(null), I = (e, n) => {
		let r = s$16(e), i = r[WEVU_RUNTIME_KEY], a = i?.proxy, o = (e, t) => {
			let n = e[t];
			return n$8(n);
		}, s = (t) => !(!t || typeof t != `object` || t === e || t === n || t === a || o(t, `triggerEvent`) || o(t, `createSelectorQuery`) || o(t, `createIntersectionObserver`) || o(t, `setData`)), l = r[WEVU_NATIVE_INSTANCE_KEY];
		if (s(l)) return l;
		let u = i?.instance;
		if (s(u)) return u;
	}, L = (e) => {
		if (i$15(O, e)) return;
		let t = (...t) => {
			let n = I(x, x);
			if (!n) return;
			let r = Reflect.get(n, e);
			if (typeof r == `function`) return r.apply(n, t);
		};
		t$8(t), O[e] = t;
	}, R = (e, t) => {
		let n = /* @__PURE__ */ new Set(), r = e;
		for (; r && !n.has(r);) {
			n.add(r);
			let e = r[WEVU_RUNTIME_APP_KEY]?.config?.globalProperties;
			if (e && i$15(e, t)) return {
				found: !0,
				value: e[t]
			};
			r = r[WEVU_PARENT_INSTANCE_KEY];
		}
		let a = typeof globalThis < `u` ? globalThis.getApp : void 0;
		if (typeof a == `function`) try {
			let e = a()?.[WEVU_RUNTIME_APP_KEY]?.config?.globalProperties;
			if (e && i$15(e, t)) return {
				found: !0,
				value: e[t]
			};
		} catch {}
		return {
			found: !1,
			value: void 0
		};
	}, z = (e) => {
		let t = e && Reflect.get(e, `selectOwnerComponent`);
		if (typeof t == `function`) try {
			let n = t.call(e);
			if (!n || typeof n != `object`) return;
			let r = Reflect.get(n, WEVU_RESOLVE_PUBLIC_INSTANCE_METHOD);
			if (typeof r == `function`) {
				let e = r.call(n);
				if (e) return e;
			}
			return n["__wevuRuntime"]?.proxy ?? n.__wevu?.proxy ?? n;
		} catch {
			return;
		}
	}, B = new Proxy(x, {
		get(n, r, a) {
			if (typeof r == `string`) {
				if (P.value, i$15(S, r)) return Reflect.get(S, r, a);
				if (r === `props`) {
					let e = n[WEVU_PROPS_KEY];
					if (e && typeof e == `object`) return e;
				}
				if (r === `$props`) {
					let e = n[WEVU_PROPS_KEY];
					if (e && typeof e == `object`) return e;
				}
				let c = n[WEVU_PROPS_KEY];
				if (c && typeof c == `object` && i$15(c, r)) return Reflect.get(c, r);
				if (r === `data` || r === `$state`) return x;
				if (r === `$computed`) return N;
				if (r === `$emit`) return (e, ...t) => {
					let r = I(n, a), i = r && Reflect.get(r, `triggerEvent`);
					if (typeof i != `function`) return;
					let { detail: c, options: l } = i$11(t);
					return i.call(r, r$5(e), c, l);
				};
				if (r === `$nextTick`) return async (t) => {
					await u$17();
					let r = I(n, a), i = r && Reflect.get(r, "__wevuHostCommitPromise");
					if (i && (typeof i == `object` || typeof i == `function`) && `then` in i && typeof i.then == `function` && await i, t) return t.call(B);
				};
				if (r === `$set`) return (e, t, n) => (Reflect.set(e, t, n), n);
				if (r === `$delete`) return (e, t) => Reflect.deleteProperty(e, t);
				if (r === `$slots`) return s$16(n).$slots ?? Object.freeze(Object.create(null));
				if (r === `$refs`) return s$16(n).$refs ?? Object.create(null);
				if (r === `$parent`) return z(I(n, a));
				if (r === `$options`) {
					let e = I(n, a);
					return { name: e?.["__wevuComponentName"] ?? e?.name ?? e?.is };
				}
				if (i$15(F, r)) return Reflect.get(F, r);
				if (i$15(O, r)) return O[r];
				if (k[r]) return k[r].value;
				if (i$15(T.globalProperties, r)) return T.globalProperties[r];
				let l = R(I(n, a), r);
				if (l.found) return l.value;
			}
			if (!Reflect.has(n, r)) {
				let e = I(n, a);
				if (e && Reflect.has(e, r)) {
					let t = Reflect.get(e, r);
					return typeof t == `function` ? t.bind(e) : t;
				}
			}
			let c = Reflect.get(n, r, a);
			return typeof r == `string` && i$15(S, r) ? Reflect.get(S, r, a) : c;
		},
		set(e, t, r, o) {
			if (typeof t == `string` && k[t]) return e$5(A, t, r), !0;
			if (i$15(S, t)) {
				let e = Reflect.get(S, t, o);
				return s$15(e) && !s$15(r) ? (e.value = r, !0) : Reflect.set(S, t, r, o);
			}
			if (i$15(F, t)) return Reflect.set(F, t, r);
			if (Reflect.has(e, t)) {
				let a = Reflect.get(e, t, o);
				return s$15(a) && !s$15(r) ? (a.value = r, !0) : i$15(e["__wevuProps"] ?? {}, t) ? Reflect.set(S, t, r, o) : Reflect.set(e, t, r, o);
			}
			return Reflect.set(F, t, r);
		},
		has(e, t) {
			if (t === `data` || t === `$emit` || t === `$nextTick` || t === `$set` || t === `$delete` || t === `$slots` || t === `$refs` || t === `$parent` || t === `$options` || typeof t == `string` && (i$15(S, t) || k[t] || i$15(O, t)) || i$15(F, t)) return !0;
			let n = I(e, e);
			return typeof t == `string` && R(n, t).found || n && Reflect.has(n, t) ? !0 : Reflect.has(e, t);
		},
		ownKeys(e) {
			let t = /* @__PURE__ */ new Set();
			return Reflect.ownKeys(e).forEach((e) => {
				t.add(e);
			}), Reflect.ownKeys(S).forEach((e) => {
				t.add(e);
			}), Reflect.ownKeys(F).forEach((e) => t.add(e)), Object.keys(O).forEach((e) => t.add(e)), Object.keys(k).forEach((e) => t.add(e)), [...t];
		},
		getOwnPropertyDescriptor(e, t) {
			if (typeof t == `string` && i$15(S, t)) return Object.getOwnPropertyDescriptor(S, t);
			if (i$15(F, t)) return Object.getOwnPropertyDescriptor(F, t);
			if (Reflect.has(e, t)) return Object.getOwnPropertyDescriptor(e, t);
			if (typeof t == `string`) {
				if (t === `data`) return {
					configurable: !0,
					enumerable: !1,
					get() {
						return x;
					}
				};
				if (k[t]) return {
					configurable: !0,
					enumerable: !0,
					get() {
						return k[t].value;
					},
					set(e) {
						e$5(A, t, e);
					}
				};
				if (i$15(O, t)) return {
					configurable: !0,
					enumerable: !1,
					value: O[t]
				};
			}
		}
	});
	return Object.keys(w).forEach((e) => {
		let t = w[e];
		if (typeof t == `function`) {
			O[e] = (...e) => t.apply(B, e);
			return;
		}
		e === "__weapp_vite_inline_map" && t && typeof t == `object` && (O[e] = t);
	}), L(`triggerEvent`), L(`createSelectorQuery`), L(`createIntersectionObserver`), L(`setData`), Object.keys(C).forEach((e) => {
		let t = C[e];
		if (typeof t == `function`) k[e] = M(e, () => t.call(B));
		else {
			let n = t.get?.bind(B);
			if (!n) throw Error(`计算属性 "${e}" 需要提供 getter`);
			let r = t.set?.bind(B);
			r ? (A[e] = r, k[e] = M(e, n, r)) : k[e] = M(e, n);
		}
	}), {
		boundMethods: O,
		computedRefs: k,
		computedSetters: A,
		dirtyComputedKeys: j,
		computedProxy: N,
		publicInstance: B,
		touchSetupMethodsVersion() {
			P.value += 1;
		}
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/diagnostics.mjs
function e$3(e) {
	return e !== `patch` && e !== `diff`;
}
function t$2(t) {
	if (t !== `off`) return (n) => {
		if (t === `fallback` && !e$3(n.reason)) return;
		let r = typeof n.bytes == `number` ? n.bytes : n.estimatedBytes, i = typeof r == `number` ? `${r}B` : `unknown`, a = [
			`mode=${n.mode}`,
			`reason=${n.reason}`,
			`pending=${n.pendingPatchKeys}`,
			`keys=${n.payloadKeys}`,
			`bytes=${i}`
		];
		if (typeof n.revision == `number` && a.push(`revision=${n.revision}`), typeof n.committedRevision == `number` && a.push(`committedRevision=${n.committedRevision}`), typeof n.mergedSiblingParents == `number` && a.push(`mergedParents=${n.mergedSiblingParents}`), typeof n.computedDirtyKeys == `number` && a.push(`computedDirty=${n.computedDirtyKeys}`), typeof n.flushCount == `number` && a.push(`flushes=${n.flushCount}`), typeof n.windowMs == `number` && a.push(`window=${n.windowMs}ms`), n.targetLabel && a.push(`target=${n.targetLabel}`), n.bindings?.length) {
			let e = n.bindings.map((e) => {
				let t = e.sourceLocation?.start;
				return t ? `${e.id}@${e.sourceFile}:${t.line}:${t.column}` : `${e.id}@${e.sourceFile}`;
			});
			a.push(`bindings=${e.join(`,`)}`);
		}
		n.message && a.push(`message=${n.message}`);
		let o = `[wevu:setData] ${a.join(` `)}`;
		if (e$3(n.reason)) {
			console.warn(o);
			return;
		}
		console.info(o);
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/setData/scheduler.mjs
function d$4(d) {
	let { state: f, setupState: p, snapshotOmitKeys: m, computedRefs: h, dirtyComputedKeys: g, includeComputed: _, setDataStrategy: v, currentAdapter: y, shouldIncludeKey: b, toPlainMaxDepth: x, toPlainMaxKeys: S, includeFunctions: C = !1, functionPaths: w, debug: T, debugWhen: ee, debugSampleRate: E, bindingManifest: D, loopWarning: O, targetLabel: k, runTracker: A, isMounted: j$2, initialSnapshot: M, initialState: N } = d, P = /* @__PURE__ */ new WeakMap(), F$2 = /* @__PURE__ */ new WeakMap(), I = {}, L = Object.create(null), R = Object.create(null), z = [], B = -1 / 0, V = new Set(N && typeof N == `object` ? Object.keys(N) : []), H = (e) => {
		if (Object.prototype.toString.call(e) !== `[object Object]`) return !1;
		let t = Object.getPrototypeOf(e);
		return t === null || t === Object.prototype;
	}, U = (e, t) => {
		if (Object.is(e, t)) return !0;
		if (Array.isArray(e) && Array.isArray(t)) return e.length === t.length && e.every((e, n) => U(e, t[n]));
		if (H(e) && H(t)) {
			let n = Object.keys(e), r = Object.keys(t);
			return n.length === r.length && n.every((n) => i$15(t, n) && U(e[n], t[n]));
		}
		return !1;
	}, W = (i) => {
		let o = s$15(i) ? i.value : i;
		if (typeof o != `object` || !o) return o;
		if (!F(o) && s$11(o)) return { snapshot: u$9(o, /* @__PURE__ */ new WeakMap(), {
			cacheEligibility: F$2,
			maxDepth: x,
			maxKeys: S,
			includeFunctions: C,
			functionPaths: w
		}) };
		let s = F(o) ? s$16(o) : o;
		return {
			raw: s,
			version: j(s)
		};
	}, G = (e, t) => Object.is(e, t) ? !0 : !e || !t || typeof e != `object` || typeof t != `object` || !i$15(e, `raw`) || !i$15(t, `raw`) ? e && t && typeof e == `object` && typeof t == `object` && i$15(e, `snapshot`) && i$15(t, `snapshot`) ? U(e.snapshot, t.snapshot) : !1 : e.raw === t.raw && e.version === t.version, K = (e) => b(e) && !m?.has(e);
	if (M) for (let [e, t] of Object.entries(M)) K(e) && (I[e] = t);
	let q = () => {
		if (!M) return;
		let t = F(f) ? s$16(f) : f, r = p && typeof p == `object` ? F(p) ? s$16(p) : p : void 0;
		for (let e of Object.keys(M)) if (K(e)) {
			if (r && i$15(r, e)) {
				L[e] = W(r[e]);
				continue;
			}
			if (i$15(t, e)) {
				if (V.has(e)) continue;
				t[e] = M[e], L[e] = W(t[e]);
			}
		}
	}, J = (t) => {
		let a = [], o = p && typeof p == `object` ? F(p) ? s$16(p) : p : void 0;
		for (let n of /* @__PURE__ */ new Set([...Object.keys(f), ...o ? Object.keys(o) : []])) {
			if (!K(n)) continue;
			let s = o && i$15(o, n) ? o[n] : f[n], c = s$15(s) ? s.value : s;
			c && typeof c == `object` && s$16(c) === t && a.push(n);
		}
		return a;
	}, Y = (e, t) => {
		if (!T) return;
		let n = e.reason !== `patch` && e.reason !== `diff`;
		if (ee === `fallback` && !n || e.reason !== `commitFailure` && E < 1 && Math.random() > E) return;
		let r = e;
		if (D) {
			let n = typeof t == `function` ? t() : t ?? [], i = e.reason === `needsFullSnapshot` || e.reason === `maxPatchKeys` || e.reason === `maxPayloadBytes`;
			r = {
				...e,
				bindings: m$3(D, n, i)
			};
		}
		try {
			T(r);
		} catch {}
	}, X = o$12({
		initialSnapshot: I,
		adapter: y,
		onFailure: (e) => {
			Y({
				mode: e.mode,
				reason: `commitFailure`,
				pendingPatchKeys: e.pendingPatchKeys,
				payloadKeys: e.payloadKeys,
				revision: e.revision,
				committedRevision: e.committedRevision,
				targetLabel: k,
				message: e.error.message
			});
			try {
				y.__wevu_reportSetDataError?.(e.error);
			} catch {}
		}
	}), te = (e = 0, t) => {
		if (!O) return;
		let n = Date.now();
		z.push(n);
		let r = n - O.sampleWindowMs;
		for (; z.length && z[0] < r;) z.shift();
		z.length <= O.maxFlushes || O.coolDownMs > 0 && n - B < O.coolDownMs || (B = n, Y({
			mode: v,
			reason: `loopWarning`,
			pendingPatchKeys: e,
			payloadKeys: 0,
			computedDirtyKeys: _ ? g.size : 0,
			flushCount: z.length,
			windowMs: O.sampleWindowMs,
			targetLabel: k,
			message: `${k ? `${k} ` : ``}疑似运行时更新循环：${z.length} 次 setData flush/${O.sampleWindowMs}ms`
		}, t));
	}, Z = () => u$8({
		state: f,
		setupState: p,
		computedRefs: h,
		includeComputed: _,
		shouldIncludeKey: K,
		plainCache: P,
		plainCacheEligibility: F$2,
		toPlainMaxDepth: x,
		toPlainMaxKeys: S,
		includeFunctions: C,
		functionPaths: w
	});
	q();
	let ne = () => {
		let t = F(f) ? s$16(f) : f, r = p && typeof p == `object` ? F(p) ? s$16(p) : p : void 0, a = X.state.dispatchedSnapshot, o = { ...a }, s = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set();
		for (let e of /* @__PURE__ */ new Set([...Object.keys(t), ...r ? Object.keys(r) : []])) {
			if (!K(e)) continue;
			l.add(e);
			let n = r && i$15(r, e) ? r : t, u = W(n[e]), f = L[e];
			f && u && typeof f == `object` && typeof u == `object` && i$15(f, `raw`) && i$15(u, `raw`) && Array.isArray(f.raw) && Array.isArray(u.raw) && f.raw !== u.raw && d.add(e), (!G(f, u) || !i$15(a, e)) && (o[e] = u$9(n[e], s, {
				cache: P,
				cacheEligibility: F$2,
				maxDepth: x,
				maxKeys: S,
				includeFunctions: C,
				functionPaths: w,
				_path: e
			})), L[e] = u;
		}
		for (let e of Object.keys(L)) l.has(e) || (delete L[e], (!_ || !i$15(h, e)) && delete o[e]);
		if (!_) {
			for (let e of Object.keys(R)) delete R[e];
			return {
				snapshot: o,
				replacedTopLevelKeys: d
			};
		}
		for (let e of Object.keys(h)) {
			if (!K(e)) continue;
			u.add(e);
			let t = h[e].value, n = W(t);
			(!G(R[e], n) || !i$15(a, e)) && (o[e] = u$9(t, s, {
				cache: P,
				cacheEligibility: F$2,
				maxDepth: x,
				maxKeys: S,
				includeFunctions: C,
				functionPaths: w,
				_path: e
			})), R[e] = n;
		}
		for (let e of Object.keys(R)) u.has(e) || (delete R[e], (!i$15(t, e) || !K(e)) && delete o[e]);
		return {
			snapshot: o,
			replacedTopLevelKeys: d
		};
	}, Q = (e = `diff`, t = 0, n) => {
		let r = v === `diff` ? ne() : void 0, i = r?.snapshot ?? Z(), a = X.state.dispatchedSnapshot, o = X.state.needsFullSnapshot, c = o ? X.createFullPayload(i) : r ? (() => {
			let e = {};
			for (let t of r.replacedTopLevelKeys) e[t] = i[t];
			return {
				...g$3(a, i, { skipKeys: r.replacedTopLevelKeys }),
				...e
			};
		})() : g$3(a, i);
		n?.(i);
		let l = Object.keys(c).length;
		if (!l && !o) return;
		let u = o ? `needsFullSnapshot` : e;
		Y({
			mode: `diff`,
			reason: u,
			pendingPatchKeys: t,
			payloadKeys: l
		}, Object.keys(c)), X.dispatch({
			mode: `diff`,
			kind: o ? `full` : `delta`,
			reason: u,
			snapshot: i,
			payload: c,
			pendingPatchKeys: t
		});
	}, $ = (e = 0, t) => j$2() ? (te(e, t), A(), !0) : !1;
	return {
		collect: Z,
		emitDebug: Y,
		getLatestSnapshot: () => X.state.dispatchedSnapshot,
		dispatchUpdate: X.dispatch,
		needsFullSnapshot: () => X.state.needsFullSnapshot,
		job: (e) => {
			if ($()) return Q(`diff`);
		},
		plainCache: P,
		plainCacheEligibility: F$2,
		prepareJob: $,
		resolveTopKeysByRoot: J,
		runDiffUpdate: Q,
		shouldIncludeSnapshotKey: K,
		snapshot: () => v === `patch` ? Z() : { ...X.state.dispatchedSnapshot },
		cloneLatestSnapshot: () => ({ ...X.state.dispatchedSnapshot }),
		dispose: X.dispose
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/setDataOptions.mjs
function e$2(e) {
	let t = e?.includeComputed ?? !0, n = e?.suspendWhenHidden ?? !1, r = e?.strategy ?? `diff`, i = typeof e?.maxPatchKeys == `number` ? Math.max(0, e.maxPatchKeys) : 1 / 0, a = typeof e?.maxPayloadBytes == `number` ? Math.max(0, e.maxPayloadBytes) : 1 / 0, o = typeof e?.mergeSiblingThreshold == `number` ? Math.max(2, Math.floor(e.mergeSiblingThreshold)) : 0, s = typeof e?.mergeSiblingMaxInflationRatio == `number` ? Math.max(0, e.mergeSiblingMaxInflationRatio) : 1.25, c = typeof e?.mergeSiblingMaxParentBytes == `number` ? Math.max(0, e.mergeSiblingMaxParentBytes) : 1 / 0, l = e?.mergeSiblingSkipArray ?? !0, u = e?.computedCompare ?? (r === `patch` ? `deep` : `reference`), d = typeof e?.computedCompareMaxDepth == `number` ? Math.max(0, Math.floor(e.computedCompareMaxDepth)) : 4, f = typeof e?.computedCompareMaxKeys == `number` ? Math.max(0, Math.floor(e.computedCompareMaxKeys)) : 200, p = e?.prelinkMaxDepth, m = e?.prelinkMaxKeys, h = e?.debug, g = e?.diagnostics ?? `off`, _ = e?.loopWarning, v = _ === !1 || _ && typeof _ == `object` && _.enabled === !1 ? !1 : {
		sampleWindowMs: typeof _ == `object` && typeof _.sampleWindowMs == `number` ? Math.max(100, Math.floor(_.sampleWindowMs)) : 1e3,
		maxFlushes: typeof _ == `object` && typeof _.maxFlushes == `number` ? Math.max(1, Math.floor(_.maxFlushes)) : 50,
		coolDownMs: typeof _ == `object` && typeof _.coolDownMs == `number` ? Math.max(0, Math.floor(_.coolDownMs)) : 5e3
	}, y = e?.debugWhen ?? `fallback`, b = typeof e?.debugSampleRate == `number` ? Math.min(1, Math.max(0, e.debugSampleRate)) : 1, x = typeof e?.elevateTopKeyThreshold == `number` ? Math.max(0, Math.floor(e.elevateTopKeyThreshold)) : 1 / 0, S = typeof e?.toPlainMaxDepth == `number` ? Math.max(0, Math.floor(e.toPlainMaxDepth)) : 1 / 0, C = typeof e?.toPlainMaxKeys == `number` ? Math.max(0, Math.floor(e.toPlainMaxKeys)) : 1 / 0, w = !!e?.includeFunctions, T = Array.isArray(e?.functionPaths) ? [...new Set(e.functionPaths.filter((e) => typeof e == `string` && e.length > 0))] : [], E = Array.isArray(e?.pick) && e.pick.length > 0 ? new Set(e.pick) : void 0, D = Array.isArray(e?.omit) && e.omit.length > 0 ? new Set(e.omit) : void 0;
	return {
		includeComputed: t,
		suspendWhenHidden: n,
		setDataStrategy: r,
		maxPatchKeys: i,
		maxPayloadBytes: a,
		mergeSiblingThreshold: o,
		mergeSiblingMaxInflationRatio: s,
		mergeSiblingMaxParentBytes: c,
		mergeSiblingSkipArray: l,
		computedCompare: u,
		computedCompareMaxDepth: d,
		computedCompareMaxKeys: f,
		prelinkMaxDepth: p,
		prelinkMaxKeys: m,
		debug: h,
		diagnostics: g,
		loopWarning: v,
		debugWhen: y,
		debugSampleRate: b,
		elevateTopKeyThreshold: x,
		toPlainMaxDepth: S,
		toPlainMaxKeys: C,
		includeFunctions: w,
		functionPaths: T,
		pickSet: E,
		omitSet: D,
		shouldIncludeKey: (e) => !(E && !E.has(e) || D && D.has(e))
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app/mount.mjs
function p$2(e, t) {
	let n = (() => {
		e();
	});
	return n.stop = () => n(), n.pause = () => {
		t?.pause?.();
	}, n.resume = () => {
		t?.resume?.();
	}, n;
}
function ce(e) {
	return typeof e == `function` ? e() : e ?? {};
}
function m$2(m) {
	let { data: le, resolvedComputed: ue, resolvedMethods: de, appConfig: h, setDataOptions: g, bindingManifest: _ } = m;
	return (m) => {
		g?.strategy === `patch` && a$15(`patchStrategy`, `createRuntimeMount(setData.strategy="patch")`);
		let v = ce(le), y = m?.__wevu_initialProps;
		if (v && typeof v == `object` && !i$15(v, "__wevuProps")) try {
			Object.defineProperty(v, WEVU_PROPS_KEY, {
				value: f$9(Object.create(null)),
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {}
		let b$3 = v && typeof v == `object` ? v[WEVU_PROPS_KEY] : void 0;
		b$3 && typeof b$3 == `object` && y && typeof y == `object` && Object.assign(b$3, y);
		let x = P(v), S = P(Object.create(null)), C = m?.__wevu_snapshotOmitKeys, fe = !!m?.__wevu_deferInitialSnapshot, w = m?.__wevu_initialSnapshot, T = m?.__wevu_initialState, E = new Set(C instanceof Set || Array.isArray(C) ? C : []);
		if (v && typeof v == `object` && !i$15(v, "__wevuSetupState")) try {
			Object.defineProperty(v, WEVU_SETUP_STATE_KEY, {
				value: S,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {}
		if (v && typeof v == `object` && T && typeof T == `object`) for (let [e, t] of Object.entries(T)) E.has(e) || (v[e] = t);
		let pe = ue, me = de, D = !0, O = [], k = /* @__PURE__ */ new Set();
		Object.keys(x).forEach((e) => {
			let t = x[e];
			s$11(t) && k.add(e);
		});
		let { includeComputed: A, setDataStrategy: j, maxPatchKeys: M, maxPayloadBytes: N, mergeSiblingThreshold: P$2, mergeSiblingMaxInflationRatio: F$1, mergeSiblingMaxParentBytes: I, mergeSiblingSkipArray: L, computedCompare: R, computedCompareMaxDepth: z, computedCompareMaxKeys: he, prelinkMaxDepth: ge, prelinkMaxKeys: _e, debug: B, diagnostics: V, loopWarning: H, debugWhen: ve, debugSampleRate: ye, elevateTopKeyThreshold: be, toPlainMaxDepth: xe, toPlainMaxKeys: Se, includeFunctions: Ce, functionPaths: we, shouldIncludeKey: Te } = e$2(g), U = t$2(V), W = V === `off` && H ? t$2(`fallback`) : void 0, Ee = B || U || W ? (e) => {
			if (typeof B == `function`) try {
				B(e);
			} catch {}
			U?.(e), e.reason === `loopWarning` && W?.(e);
		} : void 0, De = V === `always` ? `always` : ve, { boundMethods: Oe, computedRefs: G, computedSetters: ke, dirtyComputedKeys: Ae, computedProxy: je, publicInstance: K, touchSetupMethodsVersion: q } = b({
			state: x,
			setupState: S,
			computedDefs: pe,
			methodDefs: me,
			appConfig: h,
			includeComputed: A,
			setDataStrategy: j
		}), J = m ?? { setData: () => {} }, Me = J.__wevu_targetLabel, Y, X = {
			state: x,
			setupState: S,
			snapshotOmitKeys: E,
			computedRefs: G,
			dirtyComputedKeys: Ae,
			includeComputed: A,
			setDataStrategy: j,
			computedCompare: R,
			computedCompareMaxDepth: z,
			computedCompareMaxKeys: he,
			currentAdapter: J,
			shouldIncludeKey: Te,
			maxPatchKeys: M,
			maxPayloadBytes: N,
			mergeSiblingThreshold: P$2,
			mergeSiblingMaxInflationRatio: F$1,
			mergeSiblingMaxParentBytes: I,
			mergeSiblingSkipArray: L,
			elevateTopKeyThreshold: be,
			prelinkMaxDepth: ge,
			prelinkMaxKeys: _e,
			toPlainMaxDepth: xe,
			toPlainMaxKeys: Se,
			includeFunctions: Ce,
			functionPaths: we,
			debug: Ee,
			debugWhen: De,
			debugSampleRate: ye,
			bindingManifest: _,
			loopWarning: H,
			targetLabel: Me,
			runTracker: () => Y?.(),
			isMounted: () => D,
			initialSnapshot: w && typeof w == `object` ? w : void 0,
			initialState: T && typeof T == `object` ? T : void 0
		}, Z = j === `patch` ? a$15(`patchStrategy`, `createRuntimeMount(setData.strategy="patch")`).createScheduler(X) : d$4(X), Q = () => Z.job();
		Y = O$2(() => {
			g$4(x);
			let e = x[WEVU_PROPS_KEY];
			F(e) && g$4(e);
			let t = x[WEVU_ATTRS_KEY];
			F(t) && g$4(t), k.forEach((e) => {
				c$11(S[e] ?? x[e]);
			});
		}, {
			lazy: !0,
			scheduler: () => l$17(Q)
		}), fe || Q(), O.push(p$2(() => y$3(Y))), Z.start?.(), Z.dispose && O.push(p$2(Z.dispose));
		function Ne(e, t, n) {
			let r = u$12(e, (e, n) => t(e, n), n);
			return O.push(r), p$2(() => {
				r();
				let e = O.indexOf(r);
				e >= 0 && O.splice(e, 1);
			}, r);
		}
		let $ = {
			get state() {
				return x;
			},
			get setupState() {
				return S;
			},
			get proxy() {
				return K;
			},
			get methods() {
				return Oe;
			},
			get computed() {
				return je;
			},
			get adapter() {
				return J;
			},
			bindModel: l$4(K, x, G, ke, S),
			watch: Ne,
			snapshot: () => Z.snapshot(),
			unmount: () => {
				if (D) {
					D = !1, Z.dispose?.();
					try {
						J.__wevu_disposeSetData?.();
					} catch {}
					O.forEach((e) => {
						try {
							e();
						} catch {}
					}), O.length = 0;
				}
			}
		};
		try {
			Object.defineProperty($, "__wevu_touchSetupMethodsVersion", {
				value: q,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			$.__wevu_touchSetupMethodsVersion = q;
		}
		try {
			Object.defineProperty($, "__wevu_flushSetupSnapshotSync", {
				value: Q,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			$.__wevu_flushSetupSnapshotSync = Q;
		}
		try {
			Object.defineProperty($, "__wevu_cloneDispatchedSnapshot", {
				value: Z.cloneLatestSnapshot,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			$.__wevu_cloneDispatchedSnapshot = Z.cloneLatestSnapshot;
		}
		try {
			Object.defineProperty($, "__wevu_trackSetupReactiveKey", {
				value: (e) => {
					k.add(e);
				},
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			$.__wevu_trackSetupReactiveKey = (e) => {
				k.add(e);
			};
		}
		try {
			Object.defineProperty($, WEVU_PROPS_DERIVED_KEYS_KEY, {
				value: E,
				configurable: !0,
				enumerable: !1,
				writable: !1
			});
		} catch {
			$[WEVU_PROPS_DERIVED_KEYS_KEY] = E;
		}
		return $;
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/app.mjs
function _$1(_) {
	let v = _[e$20], { [e$20]: y, [WEVU_BINDING_MANIFEST_KEY]: b, [WEVU_SCOPED_SLOT_OWNER_REQUIRED_KEY]: x, data: S, computed: C, methods: w, setData: T, watch: E, setup: D, ...O } = v === `component` ? _ : c$16(_), k = s$6(b), A = w ?? {}, j = C ?? {}, M = x === !0 || Array.isArray(T?.pick) && T.pick.includes("__wvOwnerId"), N = A, P = N[WEVU_INLINE_MAP_KEY];
	Object.prototype.hasOwnProperty.call(N, "__weapp_vite_inline_map") && P && typeof P == `object` && Object.keys(P).length > 0 && typeof N["__weapp_vite_inline"] != `function` && typeof O["__weapp_vite_inline"] != `function` && a$15(`inlineEvents`, `createApp(inline event metadata)`), T?.strategy === `patch` && a$15(`patchStrategy`, `createApp(setData.strategy="patch")`), o$16(T?.highFrequencyWarning) && a$15(`setDataHighFrequencyWarning`, `createApp(setData.highFrequencyWarning)`), M && a$15(`scopedSlots`, `createApp(scoped-slot bindings)`);
	let F = /* @__PURE__ */ new Set(), I = /* @__PURE__ */ new Set(), L = !1, R = { globalProperties: {} }, z = {
		mount: m$2({
			data: S,
			resolvedComputed: j,
			resolvedMethods: A,
			appConfig: R,
			setDataOptions: T,
			bindingManifest: k
		}),
		use(e, ...t) {
			if (!e || F.has(e)) return z;
			if (F.add(e), typeof e == `function`) e(z, ...t);
			else if (typeof e.install == `function`) e.install(z, ...t);
			else throw TypeError(`插件必须是函数，或包含 install 方法的对象`);
			return z;
		},
		provide(e, t) {
			return f$7(z, e, t, { syncGlobal: v !== `component` }), z;
		},
		onUnmount(e) {
			if (typeof e != `function`) throw TypeError(`onUnmount 只接受函数`);
			return L ? (e(), z) : (I.add(e), z);
		},
		unmount() {
			if (!L) {
				L = !0;
				for (let e of I) e();
				I.clear();
			}
		},
		config: R,
		version: t$12
	};
	try {
		d$10(z), Object.defineProperty(z, "__wevuSetDataOptions", {
			value: T,
			configurable: !0,
			enumerable: !1,
			writable: !1
		}), Object.defineProperty(z, "__wevuHasTemplateRuntimeBindings", {
			value: M,
			configurable: !0,
			enumerable: !1,
			writable: !1
		});
	} catch {
		z.__wevuSetDataOptions = T, z.__wevuHasTemplateRuntimeBindings = M;
	}
	let B = () => {
		let t = f$12(), n = `__wevuAppRegistered`;
		t && t[n] || (t && (t[n] = !0), m$4(z, w ?? {}, E, D, O));
	};
	return v !== `component` && typeof App == `function` && B(), z;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/componentDefinition.mjs
function a$5(a, o = !1) {
	let s = _$1({
		data: a.data,
		computed: a.computed,
		methods: a.methods,
		setData: a.setData,
		[WEVU_BINDING_MANIFEST_KEY]: a.bindingManifest,
		[WEVU_SCOPED_SLOT_OWNER_REQUIRED_KEY]: a.scopedSlotOwnerRequired,
		[e$20]: `component`
	});
	return {
		lifecycleDefinition: c$6(s, a.methods, a.watch, a.setup, a.mpOptions, { registerNative: o }),
		runtimeApp: s
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/initialComputed.mjs
var i$4 = class extends Error {};
function a$4(e) {
	if (typeof e == `function`) return e;
	let t = e?.get;
	return typeof t == `function` ? t : void 0;
}
function o$4(e) {
	return e.startsWith(`__wv_bind_`) || e.startsWith(`__wv_cls_`) || e.startsWith(`__wv_style_`);
}
function s$4(e, t) {
	if (!e.startsWith(`__wv_bind_`)) return !1;
	try {
		return !/\bthis\b/.test(Function.prototype.toString.call(t));
	} catch {
		return !1;
	}
}
function c$3(e) {
	if (e === "__wvOwnerId") return ``;
	if (e.startsWith(`__wv_bind_`)) return null;
	if (e.startsWith(`__wv_cls_`) || e.startsWith(`__wv_style_`)) return ``;
}
function l$3(t, n) {
	let r = Array.isArray(n?.pick) ? n.pick : [];
	if (!r.length) return;
	let i = new Set(Array.isArray(n?.omit) ? n.omit : []), a = {};
	for (let n of r) {
		if (i.has(n) || i$15(t, n)) continue;
		let r = c$3(n);
		r !== void 0 && (a[n] = r);
	}
	return Object.keys(a).length ? a : void 0;
}
function u$3(r) {
	let { data: c, computed: l, methods: u, setData: d } = r, f = l ? Object.keys(l) : [];
	if (!f.length) return;
	let { includeComputed: p, shouldIncludeKey: m, toPlainMaxDepth: h, toPlainMaxKeys: g, includeFunctions: _, functionPaths: v } = e$2(d);
	if (!p) return;
	let y = {}, b = /* @__PURE__ */ new Set(), x, S = (n) => {
		if (i$15(c, n) || !m(n)) return { ok: !1 };
		if (i$15(y, n)) return {
			ok: !0,
			value: y[n]
		};
		if (b.has(n)) return { ok: !1 };
		let r = a$4(l[n]);
		if (!r) return { ok: !1 };
		b.add(n);
		try {
			let e = r.call(x);
			if (e === void 0) return { ok: !1 };
			let i = u$9(e, /* @__PURE__ */ new WeakMap(), {
				maxDepth: h,
				maxKeys: g,
				includeFunctions: _,
				functionPaths: v,
				_path: n
			});
			return i === void 0 ? { ok: !1 } : (y[n] = i, {
				ok: !0,
				value: i
			});
		} catch {
			return { ok: !1 };
		} finally {
			b.delete(n);
		}
	};
	x = new Proxy(c, {
		get(t, n, r) {
			if (typeof n == `string`) {
				if (n === `data` || n === `$state`) return c;
				if (n === `props` || n === `$props` || n === `$attrs`) throw new i$4();
				if (i$15(c, n)) return Reflect.get(t, n, r);
				if (u && i$15(u, n)) {
					let e = u[n];
					return typeof e == `function` ? e.bind(x) : e;
				}
				if (l && i$15(l, n)) {
					let e = S(n);
					if (e.ok) return e.value;
					throw new i$4();
				}
				throw new i$4();
			}
			return Reflect.get(t, n, r);
		},
		has(t, n) {
			return Reflect.has(t, n) || typeof n == `string` && !!(l && i$15(l, n));
		}
	});
	for (let e of f) {
		let t = a$4(l[e]);
		(!o$4(e) || t && s$4(e, t)) && S(e);
	}
	return Object.keys(y).length ? y : void 0;
}
function d$3(e, t, n, r) {
	if (!e || typeof e != `object`) return e;
	let i = u$3({
		data: e,
		computed: t,
		methods: r,
		setData: n
	}), a = l$3(e, n);
	return i || a ? {
		...e,
		...a,
		...i
	} : e;
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/options.mjs
var e$1 = [
	`components`,
	`computed`,
	`directives`,
	`inject`,
	`methods`,
	`props`,
	`provide`
];
var t$1 = /* @__PURE__ */ new Set(/* @__PURE__ */ `activated.attached.beforeCreate.beforeDestroy.beforeMount.beforeUnmount.beforeUpdate.created.deactivated.destroyed.detached.errorCaptured.hide.mounted.moved.onAddToFavorites.onHide.onLoad.onPageScroll.onPullDownRefresh.onReachBottom.onReady.onResize.onRouteDone.onSaveExitState.onShareAppMessage.onShareTimeline.onShow.onTabItemTap.onUnload.ready.renderTracked.renderTriggered.serverPrefetch.show.unmounted.updated`.split(`.`));
function n$1(e) {
	return e && typeof e == `object` && !Array.isArray(e) ? e : void 0;
}
function r$2(e, t) {
	return typeof e == `function` ? typeof t == `function` ? function(...n) {
		return e.apply(this, n), t.apply(this, n);
	} : e : t;
}
function i$3(e, t) {
	let i = n$1(e), a = n$1(t);
	if (!i) return a;
	if (!a) return i;
	let o = {
		...i,
		...a
	};
	for (let e of /* @__PURE__ */ new Set([...Object.keys(i), ...Object.keys(a)])) o[e] = r$2(i[e], a[e]);
	return o;
}
function a$3(e, t) {
	return e === void 0 ? t : t === void 0 ? e : function() {
		let r = typeof e == `function` ? e.call(this) : e, i = typeof t == `function` ? t.call(this) : t;
		return {
			...n$1(r) ?? {},
			...n$1(i) ?? {}
		};
	};
}
function o$3(e, t) {
	if (typeof e == `function`) return e;
	if (typeof e == `string`) {
		let n = t[e];
		return typeof n == `function` ? n : void 0;
	}
	let r = n$1(e);
	return r ? o$3(r.handler, t) : void 0;
}
function s$3(e, t) {
	if (e === void 0) return t;
	if (t === void 0) return e;
	let r = n$1(e), i = n$1(t);
	return {
		...r ?? {},
		...i ?? {},
		handler(...n) {
			return o$3(e, this)?.apply(this, n), o$3(t, this)?.apply(this, n);
		},
		immediate: !!(r?.immediate || i?.immediate),
		deep: !!(r?.deep || i?.deep)
	};
}
function c$2(e, t) {
	let r = n$1(e), i = n$1(t);
	if (!r) return i;
	if (!i) return r;
	let a = {
		...r,
		...i
	};
	for (let e of /* @__PURE__ */ new Set([...Object.keys(r), ...Object.keys(i)])) a[e] = s$3(r[e], i[e]);
	return a;
}
function l$2(e, t) {
	let n = [...Array.isArray(e) ? e : [], ...Array.isArray(t) ? t : []];
	return [...new Set(n)];
}
function u$2(o, s) {
	let u = {
		...o,
		...s
	};
	for (let t of e$1) {
		let e = n$1(o[t]), r = n$1(s[t]);
		(e || r) && (u[t] = {
			...e ?? {},
			...r ?? {}
		});
	}
	u.data = a$3(o.data, s.data), u.watch = c$2(o.watch, s.watch), u.lifetimes = i$3(o.lifetimes, s.lifetimes), u.pageLifetimes = i$3(o.pageLifetimes, s.pageLifetimes);
	for (let e of /* @__PURE__ */ new Set([...Object.keys(o), ...Object.keys(s)])) t$1.has(e) && (u[e] = r$2(o[e], s[e]));
	return (Array.isArray(o.emits) || Array.isArray(s.emits)) && (u.emits = l$2(o.emits, s.emits)), (Array.isArray(o.expose) || Array.isArray(s.expose)) && (u.expose = l$2(o.expose, s.expose)), u;
}
function d$2(e, t, r) {
	let i = n$1(t);
	if (!i || r.has(i)) return e;
	r.add(i);
	let a = e;
	if (a = d$2(a, i.extends, r), Array.isArray(i.mixins)) for (let e of i.mixins) a = d$2(a, e, r);
	let { extends: o, mixins: s, ...c } = i;
	return u$2(a, c);
}
function f$2(e) {
	return d$2({}, e, /* @__PURE__ */ new WeakSet());
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/optionsApi.mjs
var r$1 = Symbol(`wevu-missing-options-api-injection`);
function i$2(e) {
	if (typeof e == `string` || typeof e == `symbol`) return { from: e };
	if (!e || typeof e != `object`) return;
	let t = e;
	return {
		from: t.from,
		hasDefault: i$15(t, `default`),
		defaultValue: t.default
	};
}
function a$2(e, t) {
	return typeof e == `function` ? e.call(t) : e;
}
function o$2(t, n) {
	let o = {};
	if (Array.isArray(t)) {
		for (let n of t) (typeof n == `string` || typeof n == `symbol`) && (o[n] = l$10(n));
		return o;
	}
	if (!t || typeof t != `object`) return o;
	for (let [s, c] of Object.entries(t)) {
		let t = i$2(c);
		if (!t || t.from == null) continue;
		let l = l$10(t.from, r$1);
		o[s] = l === r$1 && t.hasDefault ? a$2(t.defaultValue, n) : l === r$1 ? void 0 : l;
	}
	return o;
}
function s$2(e, n) {
	let r = typeof e == `function` ? e.call(n) : e;
	if (r && typeof r == `object`) for (let e of Reflect.ownKeys(r)) c$12(e, Reflect.get(r, e));
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define/props.mjs
var i$1 = `__wevu_allowNullPropInput`;
var a$1 = `allowNullPropInput`;
var o$1 = /* @__PURE__ */ new Map([
	[String, String],
	[Number, Number],
	[Boolean, Boolean],
	[Object, Object],
	[Array, Array],
	[Function, Function],
	[`String`, String],
	[`Number`, Number],
	[`Boolean`, Boolean],
	[`Object`, Object],
	[`Array`, Array],
	[`Function`, Function],
	[null, null],
	[`null`, null],
	[`Null`, null]
]);
function s$1(e) {
	return o$1.get(e);
}
function c$1(e, t = []) {
	if (Array.isArray(e)) {
		for (let n of e) c$1(n, t);
		return t;
	}
	let n = s$1(e);
	return n !== void 0 && !t.includes(n) && t.push(n), t;
}
function l$1(e) {
	if (e === void 0) return [];
	let t = c$1(e).filter((e) => e !== null);
	return t.length > 0 ? t : [null];
}
function u$1(e, t) {
	let n = l$1(t);
	if (n.length !== 0 && (e.type = n[0], n.length > 1)) {
		let t = [];
		for (let e of n.slice(1)) t.includes(e) || t.push(e);
		t.length > 0 && (e.optionalTypes = t);
	}
}
function d$1(t) {
	i$15(t, `value`) || (t.type === String ? t.value = `` : t.type === Number ? t.value = 0 : t.type === Boolean ? t.value = !1 : t.type === Array && (t.value = []));
}
function f$1(e, t, n) {
	if (!n || e.type === null) return;
	let r = t && typeof t == `object` && !Array.isArray(t) ? t : void 0, i = c$1(r ? [r.type, r.optionalTypes] : t), a = i.includes(null), o = i.filter((e) => e !== null).length > 1, s = r?.required !== !0;
	(a || o || s) && (a || d$1(e), e.type = null, delete e.optionalTypes);
}
function p$1(t, n) {
	let r = {};
	return t && Object.entries(t).forEach(([t, i]) => {
		if (i !== void 0) {
			if (i === null) {
				r[t] = { type: null };
				return;
			}
			if (Array.isArray(i) || typeof i == `function`) {
				let a = {};
				u$1(a, i), i$15(a, `type`) || (a.type = null), f$1(a, i, n), r[t] = a;
				return;
			}
			if (typeof i == `object`) {
				if (t.endsWith(`Modifiers`) && Object.keys(i).length === 0) {
					r[t] = {
						type: Object,
						value: {}
					};
					return;
				}
				let a = {};
				if (`type` in i && i.type !== void 0 && u$1(a, i.type), Array.isArray(i.optionalTypes)) {
					let e = i.optionalTypes.map((e) => s$1(e)).filter((e) => e != null);
					if (e.length > 0) {
						let t = Array.isArray(a.optionalTypes) ? a.optionalTypes : [];
						for (let n of e) n !== a.type && (t.includes(n) || t.push(n));
						t.length > 0 && (a.optionalTypes = t);
					}
				}
				`observer` in i && (typeof i.observer == `function` || typeof i.observer == `string`) && (a.observer = i.observer);
				let o = `default` in i ? i.default : i.value;
				o !== void 0 && (a.value = typeof o == `function` ? o() : o), i$15(a, `type`) || (a.type = null), f$1(a, i, n), r[t] = a;
			}
		}
	}), r;
}
function m$1(o, s, c) {
	let l = !!(o[i$1] ?? o[a$1]), { [i$1]: u, [a$1]: d, ...f } = o, m = o.properties, h = m && typeof m == `object` && Object.keys(m).length > 0 ? m : void 0, g = c ?? h, _ = !!(s || g), v = (i) => {
		let a = { ...i ?? {} };
		return _ ? (i$15(a, "__wvSlotOwnerId") || (a["__wvSlotOwnerId"] = {
			type: String,
			value: ``
		}), i$15(a, "__wvSlotScope") || (a["__wvSlotScope"] = {
			type: null,
			value: null
		}), i$15(a, "vueSlots") || (a["vueSlots"] = {
			type: null,
			value: null
		}), a) : a;
	};
	if (g) {
		let { properties: e, ...t } = f, n = g, r = p$1(s, l);
		return {
			...t,
			properties: v({
				...r,
				...n
			})
		};
	}
	return {
		...f,
		properties: v(p$1(s, l))
	};
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/define.mjs
var x = /* @__PURE__ */ new WeakMap();
function S(e, t) {
	let r = { ...t ?? {} };
	if (!e || typeof e != `object`) return r;
	for (let [t, i] of Object.entries(e)) i && typeof i == `object` && i$15(i, `value`) && (r[t] = i.value);
	return r;
}
function C(e, t) {
	return Array.isArray(e?.pick) && e.pick.includes("__wvOwnerId") || t?.features?.scopedSlots === !0 && c$5(t, "__wvOwnerId");
}
function w(e) {
	return !!e.__wevu_isPage;
}
function T(e) {
	let t = e.properties;
	return !!(t && typeof t == `object` && ("__wvSlotOwnerId" in t || "__wvSlotScope" in t));
}
function E(e, t) {
	return t?.strategy !== `patch` || !T(e) ? t : {
		...t,
		strategy: `diff`
	};
}
function D(e, t = !1) {
	let { lifecycleDefinition: n, runtimeApp: r } = a$5(e, t), i = {
		__wevu_runtime: r,
		__wevu_options: e
	};
	return x.set(i, n), i;
}
function O(e) {
	return k(e, !0);
}
function k(n, r) {
	let { __typeProps: c, [WEVU_SCOPED_SLOT_OWNER_REQUIRED_KEY]: y, data: b, computed: x, methods: T, setData: O, watch: k, setup: A, props: j, inject: M, provide: N, allowFunctionProps: P, [WEVU_BINDING_MANIFEST_KEY]: F, [WEVU_CSS_MODULES_KEY]: I, ...L } = f$2(l$13(n)), R = s$6(F), z = L[WEVU_FUNCTION_PROP_PATHS_KEY], B = Array.isArray(z) ? [...new Set(z.filter((e) => typeof e == `string` && e.length > 0))] : [];
	delete L[WEVU_FUNCTION_PROP_PATHS_KEY];
	let V = E(L, P === !0 ? {
		...O ?? {},
		includeFunctions: !0,
		functionPaths: B
	} : P === !1 ? O : B.length ? {
		...O ?? {},
		functionPaths: B
	} : O), H = new Set(B.filter((e) => !e.includes(`.`))), U = m$1(L, j, L.properties), W = S(U.properties, T), G = typeof b == `function` ? () => b.call(W) : b, K = typeof A == `function` || M != null || N != null || I ? ((e, t) => {
		I && typeof I == `object` && (t.instance["__wevuCssModules"] = I);
		let n = t?.proxy ?? t?.instance ?? Object.create(null), r = o$2(M, n);
		N != null && s$2(N, n);
		let i = typeof A == `function` ? e$12(A, e, t) : void 0, c = o$9({
			...r,
			...I ?? {}
		}, i);
		return t && Object.keys(c).length && c$7(t.runtime, t.instance, c, {
			includeFunctionsInState: P === !0,
			functionPropPaths: P === !1 ? void 0 : H
		}), c;
	}) : void 0, q = typeof G == `function` ? G() : G, J = q && typeof q == `object` ? Reflect.get(q, WEVU_SLOT_OWNER_ID_KEY) : void 0, Y = C(V, R), X = Y ? a$15(`scopedSlots`, `defineComponent(scoped-slot owner metadata)`) : void 0, Q = d$3(Y ? {
		...q && typeof q == `object` ? q : {},
		[WEVU_SLOT_OWNER_ID_KEY]: w(L) ? J || X?.allocateOwnerId() : J || ``
	} : q, x, V, T), $ = Q === void 0 ? U : {
		...U,
		data: Q
	};
	return D({
		scopedSlotOwnerRequired: y === !0,
		data: G,
		computed: x,
		methods: T,
		setData: V,
		bindingManifest: R,
		watch: k,
		setup: K,
		mpOptions: $
	}, r);
}
function N(e) {
	let t = e.allowNullPropInput ?? !0;
	O({
		...e,
		allowNullPropInput: t,
		__wevu_allowNullPropInput: t
	});
}
//#endregion
//#region ../../node_modules/.pnpm/wevu@7.4.0_@babel+core@8.0.6_miniprogram-api-typings@5.2.3_rolldown@1.2.11_rollup@4.63.5_typescript@6.0.3_vitest@5.0.3/node_modules/wevu/dist/runtime/inlineDataset.mjs
var e = /&amp;/g;
var t = /&quot;/g;
var n = /&#34;/g;
var r = /&apos;/g;
var i = /&#39;/g;
var a = /&lt;/g;
var o = /&gt;/g;
var s = /^(?:0|[1-9]\d*)$/;
var c = /[^a-z0-9]+/gi;
var l = /^-+|-+$/g;
var u = /-([a-z0-9])/g;
var d = /[-_]/g;
function f(e) {
	if (typeof e == `number` && Number.isFinite(e)) return e;
	if (typeof e == `string` && e.trim()) {
		let t = e.trim();
		return s.test(t) ? Number(t) : t;
	}
}
function p(e) {
	return e.trim().replace(c, `-`).replace(l, ``).toLowerCase();
}
function m(e, t) {
	let n = t.replace(d, ``).toLowerCase();
	for (let [t, r] of Object.entries(e)) if (t.replace(d, ``).toLowerCase() === n) return r;
}
function h(e, t) {
	let n = p(t && typeof t == `object` && `type` in t && typeof t.type == `string` ? t.type : ``);
	if (!n) return;
	let r = n.replace(u, (e, t) => t.toUpperCase());
	if (r) return `${e}${r[0].toUpperCase()}${r.slice(1)}`;
}
var g = {
	wvEventDetail: [`wd`, `wvEventDetail`],
	wvHandler: [`wh`, `wvHandler`],
	wvInlineId: [`wi`, `wvInlineId`]
};
function _(s) {
	return s.replace(e, `&`).replace(t, `"`).replace(n, `"`).replace(r, `'`).replace(i, `'`).replace(a, `<`).replace(o, `>`);
}
function v(e, t, n) {
	let r = g[t] ?? [t];
	for (let t of r) {
		let r = h(t, n);
		if (r && e[r] !== void 0) return e[r];
		if (r) {
			let t = m(e, r);
			if (t !== void 0) return t;
		}
	}
	for (let t of r) {
		if (e[t] !== void 0) return e[t];
		let n = m(e, t);
		if (n !== void 0) return n;
	}
}
function y(e) {
	return f(e);
}
//#endregion
Object.defineProperty(exports, "N", {
	enumerable: true,
	get: function() {
		return N;
	}
});
Object.defineProperty(exports, "WEVU_INLINE_MAP_KEY", {
	enumerable: true,
	get: function() {
		return WEVU_INLINE_MAP_KEY;
	}
});
Object.defineProperty(exports, "_", {
	enumerable: true,
	get: function() {
		return _;
	}
});
Object.defineProperty(exports, "_$1", {
	enumerable: true,
	get: function() {
		return _$1;
	}
});
Object.defineProperty(exports, "i", {
	enumerable: true,
	get: function() {
		return i$16;
	}
});
Object.defineProperty(exports, "l", {
	enumerable: true,
	get: function() {
		return l$14;
	}
});
Object.defineProperty(exports, "o", {
	enumerable: true,
	get: function() {
		return o$18;
	}
});
Object.defineProperty(exports, "o$1", {
	enumerable: true,
	get: function() {
		return o$24;
	}
});
Object.defineProperty(exports, "s", {
	enumerable: true,
	get: function() {
		return s$14;
	}
});
Object.defineProperty(exports, "s$1", {
	enumerable: true,
	get: function() {
		return s$15;
	}
});
Object.defineProperty(exports, "u", {
	enumerable: true,
	get: function() {
		return u$17;
	}
});
Object.defineProperty(exports, "v", {
	enumerable: true,
	get: function() {
		return v;
	}
});
Object.defineProperty(exports, "y", {
	enumerable: true,
	get: function() {
		return y;
	}
});
